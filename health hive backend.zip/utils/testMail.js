import dotenv from "dotenv";
import sendEmail from "./SendEmail.js";

dotenv.config();

await sendEmail({
  to: "healthhive.app.official@gmail.com",
  subject: "HealthHive Email Test",
  html: "<h3>Email system is working 🚀</h3>",
});

console.log("Test email sent");
