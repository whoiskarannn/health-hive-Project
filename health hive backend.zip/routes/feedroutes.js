import express from "express";
import Question from "../models/Questions.js";
import Post from "../models/Posts.js";

const router = express.Router();

router.get("/", async (req, res) => {  //route for getting data 
  try {
    const questions = await Question.find().lean();
    const posts = await Post.find().lean();
      
    const feed = [
      ...questions.map(q => ({ ...q, type: "question" })),
      ...posts.map(p => ({ ...p, type: "post" }))
    ];
    
    res.json(feed);
  } catch (error) {
    res.status(500).json({ message: "Failed to fetch feed" });
  }
});


export default router;