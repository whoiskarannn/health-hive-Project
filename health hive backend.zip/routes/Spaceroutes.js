import express from "express";
import Space from "../models/Space.js";

const router = express.Router();

// TEST ROUTE
router.get("/test", (req, res) => {
  res.send("Spaces API working");
});

// GET ALL SPACES
router.get("/", async (req, res) => {
  try {
    const spaces = await Space.find();
    res.json(spaces);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET SPACE BY ID
router.get("/:id", async (req, res) => {
  try {
    const space = await Space.findById(req.params.id);
    res.json(space);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/* POST create space */
router.post("/", async (req, res) => {
  try {
    const { title, description, icon } = req.body;

    if (!title) {
      return res.status(400).json({ message: "Title is required" });
    }

    const slug = title
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/(^-|-$)/g, "");

    const space = new Space({
      title,
      description,
      icon,
      slug,
    });

    await space.save();
    res.status(201).json(space);

  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Space creation failed" });
  }
});

export default router;
