import mongoose from "mongoose";

const userSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      trim: true,
    },

    email: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
    },

    password: {
      type: String,
      required: true,
    },

    role: {
      type: String,
      enum: ["doctor", "pharmacist", "student", "user", "guest"],
      default: "user",
    },

    isEmailVerified: {
      type: Boolean,
      default: false,
    },

    isRoleVerified: {
      type: Boolean,
      default: false,
    },

    emailVerificationToken: String,
    emailVerificationExpires: Date,
  },
  { timestamps: true }
);

const User = mongoose.model("User", userSchema);
export default User;



// 📚 Reference:
// MongoDB Mongoose Schema — https://mongoosejs.com/docs/guide.html