import mongoose from "mongoose";

const QuestionSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: true,
      trim: true,
    },
    description: {
      type: String,
      default: "",
    },
    postedBy: {
      type: String,
      default: "Anonymous",
    },
    method: {
      type: String,
      enum: ["guest", "user"],
      default: "guest",
    },
  },
  { timestamps: true }
);

export default mongoose.model("Questions", QuestionSchema);
