import express from "express";
import User from "../models/User.js";
import bcrypt from "bcryptjs";
import crypto from "crypto";
import user from "../models/User.js";
import sendEmail from "../utils/SendEmail.js";
import jwt from "jsonwebtoken";



const router = express.Router();

// =========================== REGISTER USER =========================
router.post("/register", async (req, res) => {
  try {
    const { role, name, email, password } = req.body;

    // ---------- 1. Validate role ----------
    if (!role) {
      return res.status(400).json({ message: "Role is required" });
    }

    // =================================================
    // CASE 1: REGISTERED GUEST
    // =================================================
    if (role === "guest") {
      const guestId = "guest_" + crypto.randomUUID();
      const guestToken = crypto.randomBytes(32).toString("hex");

      const guestEmail = `${guestId}@guest.healthhive.local`;

      const guestUser = new User({
        role: "guest",
        name: name?.trim() || "Anonymous",
        email: guestEmail,               // ✅ REQUIRED
        password: crypto.randomBytes(16).toString("hex"), // ✅ REQUIRED
        guestId,
        isEmailVerified: true,
        isRoleVerified: true,
      });

      await guestUser.save();

      return res.status(201).json({
        message: "Registered as guest",
        user: {
          id: guestUser._id,
          role: guestUser.role,
          name: guestUser.name,
          guestId,
        },
        guestToken,
      });
    }


    // =================================================
    // CASE 2: IDENTIFIED USERS (user, student, doctor, pharmacist)
    // =================================================

    if (!email || !password) {
      return res
        .status(400)
        .json({ message: "Email and password are required" });
    }

    // Check if email already exists
    const existingUser = await User.findOne({ email: email.toLowerCase() });
    if (existingUser) {
      return res.status(409).json({ message: "Email already registered" });
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Generate email verification token
    const emailVerifyToken = crypto.randomBytes(32).toString("hex");
    const emailVerifyExpires = new Date(Date.now() + 30 * 60 * 1000); // 30 min

    // Create user
    const user = new User({
      role,
      name: name.trim(),
      email: email.toLowerCase().trim(),
      password: hashedPassword,
      isEmailVerified: false,
      isRoleVerified: false,
      emailVerifyToken,
      emailVerifyExpires,
    });

    await user.save();

    // Send verification email
    const verifyUrl = `${process.env.BASE_URL}/verify-email?token=${emailVerifyToken}`;

    await sendEmail({
      to: user.email,
      subject: "Verify your email",
      html: `
        <h2>Welcome to HealthHive</h2>
        <p>Please verify your email by clicking the link below:</p>
        <a href="${verifyUrl}">Verify Email</a>
        <p>This link will expire in 30 minutes.</p>
      `,
    });

    console.log(`Verification email sent to ${user.email}: ${verifyUrl}`);

    return res.status(201).json({
      message: "Registration successful. Please verify your email.",
    });
  } catch (error) {
    console.error("Register error:", error);
    return res.status(500).json({ message: "Registration failed" });
  }
});

// =========================== VERIFY EMAIL =========================
router.get("/verify-email", async (req, res) => {
  try {
    const { token } = req.query;
    if (!token) return res.status(400).send("Verification token missing");

    const user = await User.findOne({
      emailVerifyToken: token,
      emailVerifyExpires: { $gt: Date.now() },
    });

    if (!user) return res.status(400).send("Invalid or expired verification link");

    // Mark email as verified
    user.isEmailVerified = true;
    user.emailVerifyToken = undefined;
    user.emailVerifyExpires = undefined;

    await user.save();

    console.log(`User ${user.email} verified successfully.`);

    // Instant redirect to frontend homepage
    return res.redirect(`${process.env.CLIENT_URL}/login?verified=true`);

  } catch (error) {
    console.error("Email verification error:", error);
    return res.status(500).send("Email verification failed");
  }
});

// ====================== login ========================
router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        message: "Email and password are required",
      });
    }

    const user = await User.findOne({ email });

    if (!user) {
      return res.status(401).json({
        message: "Invalid credentials",
      });
    }

    const isMatch = await bcrypt.compare(password, user.password || "");

    if (!isMatch) {
      return res.status(401).json({
        message: "Invalid credentials",
      });
    }

    if (!user.isEmailVerified) {
      return res.status(403).json({
        message: "Please verify your email before logging in",
      });
    }

    const token = jwt.sign(
      {
        userId: user._id,
        role: user.role,
      },
      process.env.JWT_SECRET,
      { expiresIn: "7d" }
    );

    res.json({
      token,
      user: {
        id: user._id,
        name: user.name,
        role: user.role,
        avatar: user.avatar,
        isEmailVerified: user.isEmailVerified,
        isRoleVerified: user.isRoleVerified,
      },
    });
  } catch (error) {
    console.error("Login error:", error);
    res.status(500).json({
      message: "Login failed",
    });
  }
});



export default router;