import express from "express";
import Question from "../models/Questions.js";

const router = express.Router();

router.get("/", async (req, res) => {  // fetching questions list
  try {
    const questions = await Question.find().sort({ createdAt: -1 });
    res.json(questions);
  } catch (error) {
    res.status(500).json({ message: "Failed to fetch questions" });
  }
});

router.post("/", async (req, res) => { // pushing new questions into questions list
  try {
    const { title, description } = req.body;

    if (!title || title.trim() === "") {
      return res.status(400).json({ message: "Title is required" });
    }

    const question = new Question({
      title,
      description,
      postedBy: "Anonymous",
      method: "guest",
      type : "questions",
    });

    await question.save();

    res.status(201).json(question);
  } catch (error) {
    res.status(500).json({ message: "Failed to create question" });
  }
});


export default router;

// pls check the backend post connection 

// What this API does
// GET all questions
// Return array
// No auth
// No pagination