import { useState, useEffect } from "react";
import "./AskPost.css";
import { createQuestion, createPost } from "../api/QAapi.js";



function AskPost({ isOpen, activeTab = "ask", onClose }) {
  const [tab, setTab] = useState(activeTab);
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");

  useEffect(() => {
    setTab(activeTab);
  }, [activeTab]);

  if (!isOpen) return null;


  const handleSubmit = async () => {   // submit button for ask and post
    try {
      if (tab === "ask") {  // for asking question
        await createQuestion({
          title,
          content,
        });
        console.log("Question Added")
      } else if (tab === "post"){
        await createPost({ // for posting something
          title,
          content,
        });
        console.log("Post created")
      }

      onClose();
    } catch (error) {
      console.error("Submission failed", error);
    }
  };


  return (
    <div className="askpost-overlay">
      <div className="askpost-modal">
        {/* Header */}
        <div className="askpost-header">
          <div className="askpost-tabs">
            <button
              className={tab === "ask" ? "active" : ""}
              onClick={() => setTab("ask")}
            >
              Ask
            </button>
            <button 
              className={tab === "post" ? "active" : ""}
              onClick={() => setTab("post")}
            >
              Post
            </button>
          </div>

          <button className="close-btn" onClick={onClose}>
            ✕
          </button>
        </div>

        {/* Body */}
        <div className="askpost-body">
          {tab === "ask" && (
            <>
              <input
                type="text"
                placeholder="Start your question with What, Why, How, etc."
                value={title}
                onChange={(e) => setTitle(e.target.value)}
              />

              <textarea
                placeholder="Add more details (optional)"
                value={content}
                onChange={(e) => setContent(e.target.value)}
              />

              <div className="meta-row">
                <span>📌 Medical</span>
                <span>🌐 Public</span>
              </div>
            </>
          )}

          {tab === "post" && (
            <>
              <input
                type="text"
                placeholder="Write something"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
              />
              <textarea
                placeholder="Say something..."
                value={content}
                onChange={(e) => setContent(e.target.value)}
              />

              <div className="meta-row">
                <span>🌐 Public</span>
              </div>
            </>
          )}
        </div>

        {/* Footer */}
        <div className="askpost-footer">
          <button className="cancel-btn" onClick={onClose}>
            Cancel
          </button>

          <button
            type="button"
            className="askpost-submit-btn"
            onClick={handleSubmit}
          >
            {tab === "ask" ? "Add Question" : "Post"}
          </button>


        </div>
      </div>
    </div>
  );
}

export default AskPost;