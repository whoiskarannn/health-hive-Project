import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./css/CreateSpace.css";

const CreateSpace = () => {
  const navigate = useNavigate();

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [icon, setIcon] = useState("📌");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    if (!title.trim()) {
      setError("Space title is required");
      return;
    }

    setLoading(true);

    try {
      const res = await fetch("http://localhost:5000/api/spaces", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          title,
          description,
          icon,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.message || "Failed to create space");
      }

      // redirect to space page
      navigate(`/space/${data.slug}`);

    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="create-space-container">
      <h1>Create a Space</h1>
      <p className="subtitle">
        Spaces help organize questions, posts, and discussions.
      </p>

      <form className="create-space-form" onSubmit={handleSubmit}>
        {/* Title */}
        <label>
          Space Name
          <input
            type="text"
            placeholder="Inbox"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />
        </label>

        {/* Description */}
        <label>
          Description
          <textarea
            placeholder="What is this space about?"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
          />
        </label>

        {/* Icon */}
        <label>
          Space Icon (emoji)
          <input
            type="text"
            value={icon}
            onChange={(e) => setIcon(e.target.value)}
            maxLength={2}
          />
        </label>

        {/* Error */}
        {error && <div className="error">{error}</div>}

        {/* Submit */}
        <button type="submit" disabled={loading}>
          {loading ? "Publishing..." : "Publish Space"}
        </button>
      </form>
    </div>
  );
};

export default CreateSpace;
