// MapPage.jsx — FINAL, CLEAN, CONSISTENT VERSION
// ------------------------------------------------------------------
// RULES:
// 1. Map loads immediately
// 2. Dragging pin = PREVIEW ONLY (no address / POI updates)
// 3. "Search this area" is the ONLY commit action
// 4. All POIs (hospital / clinic / pharmacy) are fetched ONCE per search
// 5. POIs are cached client-side; category switch is instant
// 6. When previewing (pin dragged), ALL POIs are hidden
// 7. Category buttons disabled while previewing
// 8. Go Back & Search buttons appear ONLY after pin drag
// ------------------------------------------------------------------

import React, { useEffect, useRef, useState } from "react";
import { useSearchParams } from "react-router-dom";
import axios from "axios";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import "./css/MapPage.css"

/* ================= ICON HELPERS ================= */
const faMarker = (iconClass, color) =>
  L.divIcon({
    html: `<div style="background:${color};width:36px;height:36px;border-radius:50% 50% 50% 0;transform:rotate(-45deg);position:relative">
             <i class="${iconClass}" style="color:white;font-size:16px;position:absolute;top:8px;left:9px;transform:rotate(45deg)"></i>
           </div>`,
    iconSize: [36, 36],
    iconAnchor: [18, 36],
    className: "",
  });

const ICONS = {
  center: faMarker("fa-solid fa-location-dot", "#facc15"),
  hospital: faMarker("fa-solid fa-hospital", "#dc2626"),
  clinic: faMarker("fa-solid fa-user-doctor", "#16a34a"),
  pharmacy: faMarker("fa-solid fa-square-plus", "#7c3aed"),
};

const CATEGORY_OPTIONS = [
  { key: "hospital", label: "Hospitals", icon: "fa-hospital" },
  { key: "clinic", label: "Clinics", icon: "fa-user-doctor" },
  { key: "pharmacy", label: "Pharmacy", icon: "fa-square-plus" },
];

const DEFAULT_RADIUS = 5000;
const DEFAULT_PLACE = "Mumbai";

export default function MapPage() {
  const [params, setSearchParams] = useSearchParams();
  const initialCategory = params.get("category") || "hospital";
  const place = params.get("place") || DEFAULT_PLACE;

  /* ================= STATE ================= */
  const [previewCoords, setPreviewCoords] = useState(null); // pin movement
  const [searchCoords, setSearchCoords] = useState(null);   // committed coords
  const [radius, setRadius] = useState(DEFAULT_RADIUS);
  const [currentAddress, setCurrentAddress] = useState(null);

  const [allPOIs, setAllPOIs] = useState([]);               // cached POIs
  const [selectedCategory, setSelectedCategory] = useState(initialCategory);

  const [areaDirty, setAreaDirty] = useState(false);        // ONLY true after pin drag
  const [showHint, setShowHint] = useState(false);

  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState([]);

  /* ================= REFS ================= */
  const mapRef = useRef(null);
  const centerMarkerRef = useRef(null);
  const circleRef = useRef(null);
  const poiMarkersRef = useRef([]);

  /* ================= INITIAL GEOCODE ================= */
  useEffect(() => {
    axios
      .get("https://nominatim.openstreetmap.org/search", {
        params: { q: place, format: "json", limit: 1 },
      })
      .then((res) => {
        if (!res.data?.[0]) return;
        const lat = +res.data[0].lat;
        const lon = +res.data[0].lon;
        setPreviewCoords({ lat, lon });
        setSearchCoords({ lat, lon });
      });
  }, [place]);

  /* ================= MAP INIT ================= */
  useEffect(() => {
    if (!searchCoords || mapRef.current) return;
    mapRef.current = L.map("map").setView([searchCoords.lat, searchCoords.lon], 13);
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      attribution: "© OpenStreetMap",
    }).addTo(mapRef.current);
  }, [searchCoords]);

  /* ================= PREVIEW MARKER + CIRCLE ================= */
  useEffect(() => {
    if (!mapRef.current || !previewCoords) return;

    if (centerMarkerRef.current) mapRef.current.removeLayer(centerMarkerRef.current);
    if (circleRef.current) mapRef.current.removeLayer(circleRef.current);

    circleRef.current = L.circle([previewCoords.lat, previewCoords.lon], {
      radius,
      color: "#2563eb",
      fillOpacity: 0.2,
    }).addTo(mapRef.current);

    centerMarkerRef.current = L.marker([previewCoords.lat, previewCoords.lon], {
      draggable: true,
      icon: ICONS.center,
    })
      .addTo(mapRef.current)
      .on("dragend", (e) => {
        const { lat, lng } = e.target.getLatLng();
        setPreviewCoords({ lat, lon: lng });
        setAreaDirty(true); // ONLY here
      });
  }, [previewCoords, radius]);

  /* ================= SEARCH / GO BACK ================= */
  const handleSearchThisArea = () => {
    if (!previewCoords) return;
    setSearchCoords(previewCoords);
    setAreaDirty(false);
    setShowHint(false);
  };

  const handleGoBack = () => {
    if (!searchCoords) return;
    setPreviewCoords(searchCoords);
    setAreaDirty(false);
    setShowHint(false);
  };

  /* ================= REVERSE GEOCODE (COMMITTED ONLY) ================= */
  useEffect(() => {
    if (!searchCoords) return;
    setCurrentAddress(null);

    axios
      .get("https://nominatim.openstreetmap.org/reverse", {
        params: { lat: searchCoords.lat, lon: searchCoords.lon, format: "json" },
      })
      .then((res) => {
        if (res.data?.display_name) setCurrentAddress(res.data.display_name);
      });
  }, [searchCoords]);

  /* ================= FETCH ALL POIs (ON SEARCH ONLY) ================= */
  useEffect(() => {
    if (!mapRef.current || !searchCoords) return;

    poiMarkersRef.current.forEach((m) => mapRef.current.removeLayer(m));
    poiMarkersRef.current = [];
    setAllPOIs([]);

    const query = `
      [out:json][timeout:10];
      (
        node["amenity"="hospital"](around:${radius},${searchCoords.lat},${searchCoords.lon});
        node["amenity"="clinic"](around:${radius},${searchCoords.lat},${searchCoords.lon});
        node["amenity"="pharmacy"](around:${radius},${searchCoords.lat},${searchCoords.lon});
      );
      out;
    `;

    axios
      .post("https://overpass.kumi.systems/api/interpreter", new URLSearchParams({ data: query }))
      .then((res) => {
        setAllPOIs(res.data?.elements || []);
      });
  }, [searchCoords, radius]);

  /* ================= RENDER POIs (CLIENT-SIDE FILTER) ================= */
  useEffect(() => {
    if (!mapRef.current) return;

    // 🔒 Hide ALL POIs while previewing
    if (areaDirty) {
      poiMarkersRef.current.forEach((m) => mapRef.current.removeLayer(m));
      poiMarkersRef.current = [];
      return;
    }

    poiMarkersRef.current.forEach((m) => mapRef.current.removeLayer(m));
    poiMarkersRef.current = [];

    allPOIs
      .filter((p) => p.tags?.amenity === selectedCategory)
      .forEach((el) => {
        if (!el.lat || !el.lon) return;
        const m = L.marker([el.lat, el.lon], {
          icon: ICONS[selectedCategory],
        })
          .addTo(mapRef.current)
          .bindPopup(el.tags?.name || "Unnamed");
        poiMarkersRef.current.push(m);
      });
  }, [allPOIs, selectedCategory, areaDirty]);

  /* ================= CATEGORY CLICK ================= */
  const handleCategoryClick = (key) => {
    if (areaDirty) {
      setShowHint(true);
      return;
    }
    setSelectedCategory(key);
    setSearchParams({ category: key });
  };

  /* ================= REFINE LOCATION SEARCH ================= */
  const handleRefineSearch = async (value) => {
    setSearchQuery(value);
    if (value.length < 2) return setSearchResults([]);

    const res = await axios.get("https://nominatim.openstreetmap.org/search", {
      params: { q: value, format: "json", limit: 5 },
    });
    setSearchResults(res.data);
  };

  const handleRefineSelect = (r) => {
    const lat = +r.lat;
    const lon = +r.lon;
    setPreviewCoords({ lat, lon });
    mapRef.current.setView([lat, lon], 14);
    setSearchResults([]);
    setSearchQuery("");
  };

  /* ================= UI ================= */
  return (
    <div style={{ height: "100vh", width: "100vw" }}>
      {/* INFO BOX */}
    <div style={{ maxWidth:"400px", position: "absolute", zIndex: 1000, background: "white", padding: 10, margin: 10 }}>
      <strong>{selectedCategory}</strong>{" "}
      {currentAddress ? `near ${currentAddress}` : "(Loading)"}
      <br />
      {!areaDirty && (
        <>
          Radius: {(radius / 1000).toFixed(1)} km
          <input
            type="range"
            min="1000"
            max="5000"
            step="500"
            value={radius}
            onChange={(e) => setRadius(+e.target.value)}
          />
        </>
      )}
    </div>


      {/* CATEGORY BAR */}
      <div style={{ position: "absolute", top: 70, left: "50%", transform: "translateX(-50%)", zIndex: 1200 }}>
        {CATEGORY_OPTIONS.map((opt) => (
          <button
            key={opt.key}
            onClick={() => handleCategoryClick(opt.key)}
            style={{
              margin: 4,
              background: selectedCategory === opt.key ? "#2563eb" : "white",
              color: selectedCategory === opt.key ? "white" : "black",
              opacity: areaDirty ? 0.5 : 1,
            }}
          >
            <i className={`fa-solid ${opt.icon}`} /> {opt.label}
          </button>
        ))}
      </div>

      {/* HINT */}
      {showHint && (
        <div
          style={{
            position:"absolute",
            width:"100vw",
            height:"100vh",
            display:"flex",
            alignItems:"center",
            justifyContent:"center",
            background: "#0000002c",
            color: "white",
            padding: 10,
            gap:"20px",
            borderRadius: 8,
            zIndex: 2000,
          }}
        >
            {areaDirty && <button className="button5" onClick={handleSearchThisArea}>Search this area</button>}
            {areaDirty && <button className="button5" onClick={handleGoBack}>Go back</button>}
      
          
        </div>
      )}

      {/* REFINE SEARCH */}
      <div style={{ position: "absolute", top: 20, left: "50%", transform: "translateX(-50%)", zIndex: 1200, background: "white", padding: 8 }}>
        <input
          value={searchQuery}
          onChange={(e) => handleRefineSearch(e.target.value)}
          placeholder="Refine location…"
        />
        {searchResults.map((r, i) => (
          <div key={i} onClick={() => handleRefineSelect(r)}>
            {r.display_name}
          </div>
        ))}
      </div>

      <div id="map" style={{ height: "100%", width: "100%" }} />
    </div>
  );
}
