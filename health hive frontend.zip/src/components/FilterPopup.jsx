import React, { useState, useRef } from "react";
import { useNavigate } from "react-router-dom";
import useAutocomplete from "../hooks/useAutocomplete"; //why have i added this 
import axios from "axios";

/* ================= MAIN FILTER POPUP ================= */ // for categories and location

const FilterPopup = ({
  onClose,
  defaultPlace = "",
  defaultCategory = "hospital",
}) => {
  const [category, setCategory] = useState(defaultCategory);
  const [place, setPlace] = useState(defaultPlace);
  const [suggestions, setSuggestions] = useState([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [isValidPlace, setIsValidPlace] = useState(false);
  const [isLoadingLocation, setIsLoadingLocation] = useState(false); // 🆕 loading

  const [showMedicinePopup, setShowMedicinePopup] = useState(false);

  const navigate = useNavigate();
  const debounceRef = useRef(null);

  /* ================= LOCATION AUTOCOMPLETE ================= */

  const handlePlaceChange = (e) => {
    const value = e.target.value;
    setPlace(value);
    setShowSuggestions(true);
    setIsValidPlace(false);

    if (debounceRef.current) clearTimeout(debounceRef.current);

    if (value.trim().length < 2) {
      setSuggestions([]);
      setIsLoadingLocation(false);
      return;
    }

    setIsLoadingLocation(true);

    debounceRef.current = setTimeout(async () => {
      try {
        const res = await axios.get(
          "https://nominatim.openstreetmap.org/search",
          {
            params: {
              q: value,
              format: "json",
              addressdetails: 1,
              limit: 8,
              countrycodes: "in",
              bounded: 1,
            },
          }
        );

        setSuggestions(res.data);
      } catch (err) {
        console.error("Autocomplete error:", err);
        setSuggestions([]);
      } finally {
        setIsLoadingLocation(false);
      }
    }, 400);
  };

  const handleSuggestionClick = (s) => {
    setPlace(s.display_name);
    setIsValidPlace(true);
    setSuggestions([]);
    setShowSuggestions(false);
  };

  const handleUseMyLocation = () => {
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const coords = `${pos.coords.latitude},${pos.coords.longitude}`;
        setPlace(coords);
        setIsValidPlace(true);
        setSuggestions([]);
        setShowSuggestions(false);
      },
      () => alert("Unable to retrieve location")
    );
  };

  const handleCategoryChange = (value) => {
    if (value === "medicine") {
      setShowMedicinePopup(true);
    } else {
      setCategory(value);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!isValidPlace) {
      alert("Please select a valid location");
      return;
    }

    navigate(
      `/mappage?place=${encodeURIComponent(place)}&category=${category}`
    );
    onClose();
  };

  const handleClear = () => {
    setCategory("hospital");
    setPlace("");
    setSuggestions([]);
    setShowSuggestions(false);
    setIsValidPlace(false);
  };

  /* ================= RENDER ================= */

  return (
    <>
      {showMedicinePopup ? (
        <MedicineSearchPopup
          place={place}
          onClose={() => setShowMedicinePopup(false)}
        />
      ) : (
        <div style={styles.overlay}>
          <div style={styles.popup}>
            <button onClick={onClose} style={styles.closeBtn}>✕</button>

            <h2>Search Filters</h2>

            <form onSubmit={handleSubmit} style={styles.form}>
              <label>What are you looking for?</label>
              <select
                value={category}
                onChange={(e) => handleCategoryChange(e.target.value)}
                style={styles.input}
              >
                <option value="hospital">Hospital</option>
                <option value="clinic">Clinic</option>
                <option value="pharmacy">Medical Store</option>
                <option value="medicine">Find Medicine</option>
              </select>

              <label>Where?</label>
              <div style={styles.inputWrapper}>
                <input
                  type="text"
                  value={place}
                  onChange={handlePlaceChange}
                  placeholder="Enter area or town"
                  style={styles.input}
                />

                {showSuggestions && (
                  <ul style={styles.suggestionList}>
                    {isLoadingLocation && (
                      <li style={styles.loadingItem}>Loading...</li>
                    )}

                    {!isLoadingLocation &&
                      suggestions.map((s, i) => (
                        <li
                          key={i}
                          style={styles.suggestionItem}
                          onClick={() => handleSuggestionClick(s)}
                        >
                          {s.display_name}
                        </li>
                      ))}
                  </ul>
                )}
              </div>

              <button
                type="button"
                onClick={handleUseMyLocation}
                style={styles.buttonSecondary}
              >
                Use My Location
              </button>

              <div style={{ marginTop: "1rem" }}>
                <button type="submit" style={styles.buttonPrimary}>
                  Search
                </button>
                <button
                  type="button"
                  onClick={handleClear}
                  style={styles.buttonSecondary}
                >
                  Clear
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  );
};

/* ================= MEDICINE SEARCH POPUP ================= */ //for medicine and its type

const MedicineSearchPopup = ({ place, onClose }) => {
  const navigate = useNavigate();

  const [medicineQuery, setMedicineQuery] = useState("");
  const [medicine, setMedicine] = useState(null);
  const [medicineSuggestions, setMedicineSuggestions] = useState([]);
  const [showMedicineSuggestions, setShowMedicineSuggestions] = useState(false);
  const [isValidMedicine, setIsValidMedicine] = useState(false);
  const [isLoadingMedicine, setIsLoadingMedicine] = useState(false); // 🆕 loading

  const [type, setType] = useState("");
  const debounceRef = useRef(null);

  const handleClear = () => {
    setMedicineQuery("");
    setMedicine(null);
    setMedicineSuggestions([]);
    setIsValidMedicine(false);
    setType("");
  };

  const handleMedicineChange = (e) => {
    const value = e.target.value;
    setMedicineQuery(value);
    setIsValidMedicine(false);
    setShowMedicineSuggestions(true);

    if (debounceRef.current) clearTimeout(debounceRef.current);

    if (value.trim().length < 2) {
      setMedicineSuggestions([]);
      setIsLoadingMedicine(false);
      return;
    }

    setIsLoadingMedicine(true);

    debounceRef.current = setTimeout(() => {
      const MOCK_MEDICINES = [
        "Paracetamol",
        "Ibuprofen",
        "Amoxicillin",
        "Cetirizine",
        "Azithromycin",
        "Metformin",
      ];

      const filtered = MOCK_MEDICINES.filter((m) =>
        m.toLowerCase().includes(value.toLowerCase())
      );

      setMedicineSuggestions(filtered);
      setIsLoadingMedicine(false);
    }, 300);
  };

  const handleMedicineSelect = (name) => {
    setMedicine(name);
    setMedicineQuery(name);
    setIsValidMedicine(true);
    setMedicineSuggestions([]);
    setShowMedicineSuggestions(false);
  };

  const handleSubmit = () => {
    if (!isValidMedicine) {
      alert("Please select a medicine from the list");
      return;
    }

    navigate(
      `/mappage?mode=medicine&place=${encodeURIComponent(
        place
      )}&medicine=${encodeURIComponent(medicine)}&type=${type}`
    );
    onClose();
  };

  return (
    <div style={styles.overlay}>
      <div style={styles.popup}>
        <button onClick={onClose} style={styles.closeBtn}>✕</button>

        <h2>Find Medicine</h2>

        <label>Medicine Name</label>
        <div style={styles.inputWrapper}>
          <input
            value={medicineQuery}
            onChange={handleMedicineChange}
            onFocus={() => setShowMedicineSuggestions(true)}
            placeholder="Search medicine"
            style={styles.input}
          />

          {showMedicineSuggestions && (
            <ul style={styles.suggestionList}>
              {isLoadingMedicine && (
                <li style={styles.loadingItem}>Loading...</li>
              )}

              {!isLoadingMedicine &&
                medicineSuggestions.map((m, i) => (
                  <li
                    key={i}
                    style={styles.suggestionItem}
                    onClick={() => handleMedicineSelect(m)}
                  >
                    {m}
                  </li>
                ))}
            </ul>
          )}
        </div>

        <div style={styles.medicineType}>
          <label>Medicine Type</label>
          <select
            value={type}
            onChange={(e) => setType(e.target.value)}
            style={styles.input}
          >
            <option value="">Any</option>
            <option value="tablet">Tablet</option>
            <option value="syrup">Syrup</option>
            <option value="injection">Injection</option>
            <option value="powder">Powder</option>
          </select>
        </div>

        <div style={{ display: "flex", gap: "10px", marginTop: "1rem" }}>
          <button onClick={handleSubmit} style={styles.buttonPrimary}>
            Search Medicine
          </button>
          <button
            type="button"
            onClick={handleClear}
            style={styles.buttonSecondary}
          >
            Clear
          </button>
        </div>
      </div>
    </div>
  );
};

export default FilterPopup;

/* ================= STYLES ================= */

const styles = {
  overlay: {
    position: "fixed",
    inset: 0,
    background: "rgba(0,0,0,0.6)",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    zIndex: 2000,
  },
  popup: {
    background: "#fff",
    padding: "2rem",
    borderRadius: "12px",
    width: "360px",
    position: "relative",
  },
  form: { display: "flex", flexDirection: "column" },
  inputWrapper: { position: "relative" },
  input: {
    width: "100%",
    marginTop: 8,
    marginBottom: 12,
    padding: "10px",
    borderRadius: 6,
    border: "1px solid #ccc",
    height: "40px",
    boxSizing: "border-box",
  },
  suggestionList: {
    position: "absolute",
    background: "#fff",
    width: "100%",
    zIndex: 3000,
    maxHeight: 200,
    overflowY: "auto",
    listStyle: "none",
    padding: 0,
    margin: 0,
  },
  suggestionItem: {
    padding: 10,
    cursor: "pointer",
    borderBottom: "1px solid #eee",
  },
  loadingItem: {
    padding: 10,
    fontStyle: "italic",
    color: "#666",
  },
  buttonPrimary: {
    background: "#007bff",
    color: "#fff",
    padding: 10,
    border: "none",
    borderRadius: 6,
    cursor: "pointer",
  },
  buttonSecondary: {
    background: "#eee",
    padding: 10,
    borderRadius: 6,
    border: "none",
  },
  closeBtn: {
    position: "absolute",
    top: 10,
    right: 14,
    border: "none",
    background: "none",
    fontSize: 18,
    cursor: "pointer",
  },
  medicineType: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    gap: 10,
  },
};
