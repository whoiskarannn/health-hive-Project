import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import FilterPopup from "./FilterPopup"; // Make sure path is correct
import "./css/Navbar.css"


const Navbar = () => {
  const navigate = useNavigate();
  const [showPopup, setShowPopup] = useState(false);

  const handleFilterSubmit = ({ category, location }) => {
    const encodedPlace = encodeURIComponent(location);
    const encodedCategory = encodeURIComponent(category);
    navigate(`/mappage?place=${encodedPlace}&category=${encodedCategory}`);
  };

  return (
    <>
      <div className="navbar">
        <div className="navbar-section">
          <button  className="Nav-btn">
            <i title="Home" className="fas fa-home nav-icon"></i>
          </button>
          <button  className="Nav-btn">
            <i title="News" className="fas fa-newspaper nav-icon"></i>
          </button>
          <button  className="Nav-btn">
            <i title="Post" className="fas fa-pen nav-icon"></i>
          </button>
          <button  className="Nav-btn">
            <i title="Spaces" className="fas fa-users nav-icon"></i>
          </button>
          <button  className="Nav-btn">
            <i title="Notifications" className="fas fa-bell nav-icon"></i>
          </button>
       
         
        
         

          {/* 🔍 Search Box */}
          <div className="search-box" onClick={() => setShowPopup(true)}>
            <i className="fas fa-search"></i>
            <input
              type="text"
              placeholder="Find medicine, hospitals and more"
              readOnly
            />
          </div>

          <img title="Profile" src="your-avatar.jpg" alt="Profile" className="profile-pic" />
        </div>
      </div>

      {showPopup && (
        <FilterPopup
          onClose={() => setShowPopup(false)}
          onSubmit={handleFilterSubmit}
        />
      )}
    </>
  );
};

export default Navbar;
