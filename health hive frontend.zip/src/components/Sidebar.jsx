import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import "./css/Sidebar.css";

const SpaceSkeleton = () => (  // for loading skeleton in case of lazy internet
  <div className="space-skeleton">
    <div className="space-skeleton-icon"></div>
    <div className="space-skeleton-text"></div>
  </div>
);


const Sidebar = () => {
  const [spaces, setSpaces] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("http://localhost:5000/api/spaces")  //always make sure to run the backend on server 5000 to see the data
      .then((res) => res.json())
      .then((data) => {
        const activeSpaces = data.filter(
          (space) => space.status === "active"
        );
        setSpaces(activeSpaces);
        setLoading(false);
      }) 
      .catch((err) => {
        console.error("Error fetching spaces:", err);
        setLoading(false);
      });
  }, []);

  if (loading) {  //this makes skeleton loading possible
    return (
      <aside className="sidebar">
        {/* Create Space Button */}
        <Link to="/create-space">
          <button className="create-space-btn">➕ Create Space</button>
        </Link>            
        <div className="spaces-section">
          <h4 className="spaces-title">Spaces</h4>    
          <div className="spaces-list">
              {[1, 2, 3, 4, 5, 6, 7].map((i) => (
                  <SpaceSkeleton key={i} />
                ))}
          </div>
        </div>
      </aside>
    )    
  }


  return (
    <aside className="sidebar">
      {/* Create Space Button */}

      <Link to="/create-space">
        <button className="create-space-btn">➕ Create Space</button>
      </Link>
          
      <div className="spaces-section">
        <h4 className="spaces-title">Spaces</h4>

        <div className="spaces-list">
          {spaces.map((space) => (
            <Link
              key={space._id}
              to={`/space/${space.slug}`}
              className="space-link"
            >
              <div className="space-item">
                <div className="space-icon">
                  {space.icon || "📌"}
                </div>
                <span className="space-name">
                  {space.title}
                </span>
              </div>
            </Link>
          ))}
        </div>
      </div>

      {/* Footer */}
      <div className="sidebar-footer">
        <a href="#">About</a> · <a href="#">Careers</a> · <a href="#">Terms</a> ·
        <a href="#">Privacy</a> · <a href="#">Press</a>
        <br />
        <a href="#">Your Ad Choices</a> · <a href="#">Grievance Officer</a>
      </div>
    </aside>
  );
};

export default Sidebar;
