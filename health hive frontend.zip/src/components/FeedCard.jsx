import "../QA/QuestionsList.css";

export default function FeedCard({ item }) {
  return (
    <div className="qa-card">
      <h3>{item.title}</h3>

      {item.description && (
        <p className="qa-description">{item.description}</p>
      )}

      {item.content && (
        <p className="qa-description">{item.content}</p>
      )}

      <div className="qa-meta">
        Posted by: {item.postedBy || "Anonymous"}
      </div>

      <div className="qa-actions">
        <button><i className="fa-regular fa-comment"></i></button>
        <button><i className="fa-solid fa-thumbs-up"></i></button>
        <button><i className="fa-solid fa-thumbs-down"></i></button>
        <button><i className="fa-solid fa-flag"></i></button>
        <button><i className="fa-solid fa-share-nodes"></i></button>
      </div>
    </div>
  );
}


// this card is used to load same looking card in feed and search results etc 