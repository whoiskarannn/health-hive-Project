import axios from "axios";

const BASE_URL = "http://localhost:5000/api";

// send question
export const createQuestion = (data) => {
  return axios.post(`${BASE_URL}/questions`, {
    title: data.title,
    description: data.content, // ✅ MUST be description
  });
};

// send post
export const createPost = (data) => {
  return axios.post(`${BASE_URL}/posts`, {
    title: data.title,
    description: data.content, // ✅ MUST be description
  });
};
