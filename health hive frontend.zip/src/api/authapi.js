
import axios from "axios";

const BASE_URL = "http://localhost:5000/api";

// register user
export const registerUser = (data) => {
  return axios.post(`${BASE_URL}/auth`, {
    name: data.name,
    email: data.email,
    password: data.password,
    role: data.role,
  });
};



export const verifyEmail = async (token) => {
  const res = await fetch(`${BASE_URL}/verify-email?token=${token}`);
  return res.json();
};
