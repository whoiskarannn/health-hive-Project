import express from "express";
import mongoose from "mongoose";
import cors from "cors";
import dotenv from "dotenv";


import authRoute from "./routes/authroutes.js"
import SpacesRoute from "./routes/Spaceroutes.js";
import questionsRoute from "./routes/questionroutes.js"
import PostsRoute from "./routes/postRoutes.js"
import feedRoute from "./routes/feedroutes.js"
import searchRoute from "./routes/searchroutes.js"
import inventoryRoutes from "./routes/inventoryRoutes.js";

dotenv.config();

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// Routes and API's
// const authRoutes = require("./routes/auth.routes");

app.use("/api/auth", authRoute)
app.use("/api/spaces", SpacesRoute);
app.use("/api/questions", questionsRoute)
app.use("/api/posts", PostsRoute)
app.use("/api/feed", feedRoute)
app.use("/api/search", searchRoute)
app.use("/api/inventory", inventoryRoutes)

// MongoDB connection
mongoose
  .connect(process.env.MONGO_URI)
  .then(() => {
    console.log("MongoDB Atlas connected");
    app.listen(process.env.PORT, () => {
      console.log(`Server running on port ${process.env.PORT}`);
    });
  })
  .catch((err) => console.error(err));

  
  
  
// This is the bakend connection environment 
// If i ever want to connect to myatlas db collecyions jus tuse this folder and
// change the collection name from "spaces" tp => "<new collection name>"