import Inventory from "../models/Inventory.js";
import csv from "csvtojson";
import Inventory from "../models/Inventory.js";

/**
 * GET pharmacist inventory
 */
export const getMyInventory = async (req, res) => {
  try {
    const inventory = await Inventory.findOne({
      pharmacist: req.user._id,
    });

    res.json(inventory || { items: [], lastUpdatedAt: null });
  } catch (err) {
    res.status(500).json({ message: "Failed to fetch inventory" });
  }
};

/**
 * CREATE / UPDATE inventory (overwrite)
 */
export const upsertInventory = async (req, res) => {
  try {
    const { items } = req.body;

    const inventory = await Inventory.findOneAndUpdate(
      { pharmacist: req.user._id },
      {
        items,
        lastUpdatedAt: new Date(),
      },
      { new: true, upsert: true }
    );

    res.json(inventory);
  } catch (err) {
    res.status(500).json({ message: "Inventory update failed" });
  }
};

export const uploadInventoryCSV = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ message: "CSV file required" });
    }

    const items = await csv().fromString(req.file.buffer.toString());

    const cleanedItems = items.map((item) => ({
      medicineName: item.medicineName?.trim(),
      brand: item.brand?.trim(),
      quantity: Number(item.quantity) || 0,
      price: item.price ? Number(item.price) : undefined,
    }));

    const inventory = await Inventory.findOneAndUpdate(
      { pharmacist: req.user._id },
      {
        items: cleanedItems,
        lastUpdatedAt: new Date(),
      },
      { new: true, upsert: true }
    );

    res.json(inventory);
  } catch (err) {
    res.status(500).json({ message: "CSV upload failed" });
  }
};
