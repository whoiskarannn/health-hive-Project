import express from "express";
import Question from "../models/Questions.js";
import Post from "../models/Posts.js";

const router = express.Router();

router.get("/", async (req, res) => {
  try {
    const q = req.query.q;
    if (!q) return res.json([]);

    const regex = new RegExp(q, "i");

    const questions = await Question.find({
      $or: [{ title: regex }, { description: regex }]
    }).lean();

    const posts = await Post.find({
      $or: [{ title: regex }, { content: regex }]
    }).lean();

    res.json([
      ...questions.map(q => ({ ...q, type: "question" })),
      ...posts.map(p => ({ ...p, type: "post" }))
    ]);
  } catch (err) {
    console.error("Search error:", err);
    res.status(500).json({ message: "Search failed" });
  }
});

export default router;
