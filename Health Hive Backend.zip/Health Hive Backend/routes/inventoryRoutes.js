import express from "express";
import multer from "multer";
import Inventory from "../models/Inventory.js";
import { verifyUser } from "../routes/authroutes.js";


const router = express.Router();
const upload = multer({ storage: multer.memoryStorage() });

/**
 * TEMP AUTH CHECK
 * Replace `req.user` population logic with your existing auth middleware later
 */
const requireAuth = (req, res, next) => {
  if (!req.user) {
    return res.status(401).json({ message: "Not authenticated" });
  }
  next();
};

/**
 * TEMP ROLE CHECK
 */
const requirePharmacist = (req, res, next) => {
  if (req.user.role !== "pharmacist") {
    return res.status(403).json({ message: "Pharmacist only" });
  }
  next();
};

/**
 * GET my inventory
 */
router.get("/me",verifyUser, requireAuth, requirePharmacist, async (req, res) => {
  const inventory = await Inventory.findOne({
    pharmacist: req.user.id,
  });

  res.json(inventory || { items: [], lastUpdatedAt: null });
});

/**
 * CREATE / UPDATE inventory (overwrite)
 */
router.post("/me",verifyUser, requireAuth, requirePharmacist, async (req, res) => {
  const { items } = req.body;

  const inventory = await Inventory.findOneAndUpdate(
    { pharmacist: req.user.id },
    {
      items,
      lastUpdatedAt: new Date(),
    },
    { new: true, upsert: true }
  );

  res.json(inventory);
});

/**
 * CSV upload
 */
router.post(
  "/upload-csv",
  verifyUser,
  requireAuth,
  requirePharmacist,
  upload.single("file"),
  async (req, res) => {
    const csv = (await import("csvtojson")).default;
    const items = await csv().fromString(req.file.buffer.toString());

    const cleaned = items.map((i) => ({
      medicineName: i.medicineName?.trim(),
      brand: i.brand?.trim(),
      quantity: Number(i.quantity) || 0,
      price: i.price ? Number(i.price) : undefined,
    }));

    const inventory = await Inventory.findOneAndUpdate(
      { pharmacist: req.user.id },
      {
        items: cleaned,
        lastUpdatedAt: new Date(),
      },
      { new: true, upsert: true }
    );

    res.json(inventory);
  }
);

export default router;
