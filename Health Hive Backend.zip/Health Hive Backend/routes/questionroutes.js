import express from "express";
import Question from "../models/Questions.js";
import { verifyUser } from "../routes/authroutes.js";

const router = express.Router();

// Create question
router.post("/", verifyUser, async (req, res) => {
  try {
    const { title, description, content } = req.body;
    if (!title || title.trim() === "") return res.status(400).json({ message: "Title is required" });

   const question = new Question({
    title,
    description: description || content,
    postedBy: req.user.id,
    method: "user"
  });


    await question.save();

    res.status(201).json(question);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Failed to create question" });
  }
});

// Get questions
router.get("/", async (req, res) => {
  try {
    console.log("🔥 QUESTIONS ROUTE HIT");

  const questions = await Question.find()
    .populate("postedBy", "name avatar role");

  console.log("🔥 FIRST QUESTION:", questions[0]);
  res.json(questions);
  } catch (error) {
    res.status(500).json({ message: "Failed to fetch questions" });
  }
});

export default router;
