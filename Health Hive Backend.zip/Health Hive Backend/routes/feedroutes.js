import express from "express";
import Question from "../models/Questions.js";
import Post from "../models/Posts.js";

const router = express.Router();

router.get("/", async (req, res) => {
  try {
    const questions = await Question.find()
      .populate("postedBy", "name avatar role")
      .lean();

    const posts = await Post.find()
      .populate("postedBy", "name avatar role")
      .lean();

    const feed = [
      ...questions.map(q => ({ ...q, type: "questions" })),
      ...posts.map(p => ({ ...p, type: "posts" }))
    ];

    // 👇 ADD THIS
    // console.log("FEED SAMPLE postedBy:", feed[0]?.postedBy);

    res.json(feed);
  } catch (error) {
    console.error("Feed error:", error);
    res.status(500).json({ message: "Failed to fetch feed" });
  }
});

export default router;