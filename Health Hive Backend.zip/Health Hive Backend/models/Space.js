import mongoose from "mongoose";

const spaceSchema = new mongoose.Schema(
  {
    title: String,
    slug: String,
    icon: String,
    status: String
  },
  {
    timestamps: true,
    collection: "spaces" // EXACT collection name
  }
);
const Space = mongoose.model("Space", spaceSchema);
export default Space;
