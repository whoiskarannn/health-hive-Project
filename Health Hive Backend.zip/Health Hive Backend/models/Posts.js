import mongoose from "mongoose";

const postSchema = new mongoose.Schema(
  {
    title: { type: String, required: true },
    description: { type: String, required: true },

    postedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",          // ⭐ THIS IS THE KEY
      required: true
    },

    visibility: { type: String, default: "public" },
    type: { type: String, default: "post" },
  },
  { timestamps: true }
);

export default mongoose.model("Post", postSchema);
