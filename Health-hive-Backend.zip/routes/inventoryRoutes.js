import express from "express";
import multer from "multer";
import { verifyUser } from "../routes/authroutes.js";
import {
  getMyInventory,
  upsertInventory,
  uploadInventoryCSV,
} from "../controllers/inventoryController.js";

const router = express.Router();
const upload = multer({ storage: multer.memoryStorage() });

/**
 * Auth check
 */
const requireAuth = (req, res, next) => {
  if (!req.user) {
    return res.status(401).json({ message: "Not authenticated" });
  }
  next();
};

/**
 * Pharmacist-only check
 */
const requirePharmacist = (req, res, next) => {
  if (req.user.role !== "pharmacist") {
    return res.status(403).json({ message: "Pharmacist only" });
  }
  next();
};

/**
 * GET my inventory
 */
router.get(
  "/me",
  verifyUser,
  requireAuth,
  requirePharmacist,
  getMyInventory
);

/**
 * CREATE / UPDATE inventory
 */
router.post(
  "/me",
  verifyUser,
  requireAuth,
  requirePharmacist,
  upsertInventory
);

/**
 * CSV upload
 */
router.post(
  "/upload-csv",
  verifyUser,
  requireAuth,
  requirePharmacist,
  upload.single("file"), // must match frontend FormData key
  uploadInventoryCSV
);

export default router;
