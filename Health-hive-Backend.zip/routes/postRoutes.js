import express from "express";
import Post from "../models/Posts.js";
import { verifyUser } from "../routes/authroutes.js";

const router = express.Router();

// Create post
router.post("/", verifyUser, async (req, res) => {
  try {
    const { title, description, content } = req.body;

    if (!title || (!description && !content)) {
      return res.status(400).json({ message: "Title and content required" });
    }

    const post = new Post({
      title,
      description: description || content, // fallback
      postedBy: req.user.id,
      visibility: "public",
      type: "post",
    });

    await post.save();
    res.status(201).json(post);
  } catch (err) {
    console.error("Failed to create post:", err);
    res.status(500).json({ message: "Failed to create post" });
  }
});

// Get posts (populate user for frontend)
router.get("/", async (req, res) => {
  try {
   const posts = await Post.find()
    .sort({ createdAt: -1 })
    .populate("postedBy", "name avatar role");

  res.json(posts);
} catch (error) {
    res.status(500).json({ message: "Failed to fetch questions" });
  }
});

export default router;
