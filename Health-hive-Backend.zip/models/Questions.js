import mongoose from "mongoose";

const QuestionSchema = new mongoose.Schema(
  {
    title: { type: String, required: true },
    description: { type: String, default: "" },

    postedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",          // ⭐ SAME FIX
      required: true
    },

    method: { type: String, enum: ["guest", "user"], default: "user" }
  },
  { timestamps: true }
);

export default mongoose.model("Questions", QuestionSchema);

// we i have to say u make it easy to remember what have i done and what i need to jump on to next , so heres ,my answers and i will also guide on what i m building , cause after numerous chats with u the old guide is past u and u dont remember it ,
// 1st - this is more like a quora nd reddit
// 2nd - spaces are like communities where users see their contents posted by the users of those communities
// 3rd - 2 annonymous users , 4 identidy focused users
// 4th - primary users are students , doctors , pharmacists
// these was for your questions , now my brefing -
// i m building an three way app , means this app will works like three seperate apps (quora but only health and medicine focused , medicine finder - as name suggest ,  and online phamacy inventory managament )
// i will share the diagram later if u want , also i have built the basic 30 % of the frontend and the backed
// what have i built so far
