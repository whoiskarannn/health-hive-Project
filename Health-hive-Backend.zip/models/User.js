import mongoose from "mongoose";

const UserSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      default: "Anonymous",
      trim: true,
    },

    email: {
      type: String,
      unique: true,
      sparse: true, // IMPORTANT for guest users
      lowercase: true,
      trim: true,
    },

    password: {
      type: String,
    },

    role: {
      type: String,
      enum: ["guest", "user", "student", "doctor", "pharmacist"],
      required: true,
    },

    avatar: {
      type: String,
      default: "/default-avatar.png",
    },

    bio: {
      type: String,
      default: "",
    },

    isEmailVerified: {
      type: Boolean,
      default: false,
    },

    isRoleVerified: {
      type: Boolean,
      default: false,
    },

    emailVerifyToken: String,
    emailVerifyExpires: Date,

    guestId: {
      type: String,
    },
  },
  { timestamps: true }
);

export default mongoose.model("User", UserSchema);
