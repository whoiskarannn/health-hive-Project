// controllers/medicineController.js
import Medicine from "../models/Medicine.js";

// ADD MEDICINE
export const addMedicine = async (req, res) => {
  try {
    const medicine = new Medicine({
      ...req.body,
      createdBy: req.user.id,
    });

    await medicine.save();

    res.status(201).json({
      message: "Medicine added successfully",
      medicine,
    });
  } catch (error) {
    console.error("Add medicine error:", error);
    res.status(500).json({ message: "Failed to add medicine" });
  }
};

// GET INVENTORY
export const getMedicines = async (req, res) => {
  try {
    const medicines = await Medicine.find({
      createdBy: req.user.id,
      isActive: true,
    }).sort({ createdAt: -1 });

    res.json(medicines);
  } catch (error) {
    console.error("Get medicines error:", error);
    res.status(500).json({ message: "Failed to fetch medicines" });
  }
};
