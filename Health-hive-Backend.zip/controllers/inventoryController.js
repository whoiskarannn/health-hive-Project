import Inventory from "../models/Inventory.js";
import csv from "csvtojson";

const FIELD_ALIASES = {
  medicineName: [
    "medicinename",
    "drugname",
    "itemname",
    "productname",
    "description",
    "name",
  ],

  brand: [
    "brand",
    "brandname",        // ✅ FIX
    "manufacturer",
    "company",
    "mfg",
    "pharma",
  ],

  quantity: [
    "quantity",
    "qty",
    "qtyavailable",     // ✅ FIX
    "stock",
    "balance",
    "available",
  ],

  price: [
    "price",
    "mrp",
    "mrp₹",             // harmless if normalized
    "rate",
    "cost",
    "amount",
  ],
  expiry: [
    "expiry",
    "exp",
    "expdate",
    "expirydate",
    "expiration",
    "expiry(mm/yyyy)",
  ],

};

/**
 * GET pharmacist inventory
 */
export const getMyInventory = async (req, res) => {
  try {
    const inventory = await Inventory.findOne({
      pharmacist: req.user.id, // ✅ FIXED
    });

    res.json(inventory || { items: [], lastUpdatedAt: null });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Failed to fetch inventory" });
  }
};

/**
 * CREATE / UPDATE inventory (manual overwrite)
 */
export const upsertInventory = async (req, res) => {
  try {
    const { items } = req.body;

    const inventory = await Inventory.findOneAndUpdate(
      { pharmacist: req.user.id }, // ✅ FIXED
      {
        items,
        lastUpdatedAt: new Date(),
      },
      { new: true, upsert: true }
    );

    res.json(inventory);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Inventory update failed" });
  }
};

/**
 * CSV Upload Inventory
 */
export const uploadInventoryCSV = async (req, res) => {
  const normalizeKey = (key = "") =>
    key.toLowerCase().replace(/[^a-z0-9]/g, "");

  const resolveField = (row, aliases) => {
    for (const key of aliases) {
      if (row[key] !== undefined && row[key] !== "") {
        return row[key];
      }
    }
    return undefined;
  };

  const toNumberSafe = (value) => {
    if (!value) return undefined;
    const cleaned = String(value).replace(/[^\d.]/g, "");
    const num = Number(cleaned);
    return isNaN(num) ? undefined : num;
  };

  const parseExpiryDate = (value) => {
    if (!value) return undefined;

    const cleaned = value.trim();

    // MM/YYYY or MM-YYYY
    const mmYYYY = cleaned.match(/^(\d{1,2})[\/\-](\d{4})$/);
    if (mmYYYY) {
      return new Date(Number(mmYYYY[2]), Number(mmYYYY[1]) - 1, 1);
    }

    // DD-MM-YYYY or DD/MM/YYYY
    const ddmmyyyy = cleaned.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})$/);
    if (ddmmyyyy) {
      return new Date(
        Number(ddmmyyyy[3]),
        Number(ddmmyyyy[2]) - 1,
        Number(ddmmyyyy[1])
      );
    }

    // Fallback (ISO or readable)
    const parsed = new Date(cleaned);
    return isNaN(parsed.getTime()) ? undefined : parsed;
  };

  try {
    if (!req.file) {
      return res.status(400).json({ message: "CSV file required" });
    }

    const rows = await csv().fromString(
      req.file.buffer.toString("utf8")
    );

    const cleanedItems = rows
      .map((row) => {
        const normalizedRow = {};

        Object.keys(row).forEach((key) => {
          normalizedRow[normalizeKey(key)] = row[key]?.trim();
        });

        const medicineName = resolveField(
          normalizedRow,
          FIELD_ALIASES.medicineName
        );

        if (!medicineName) return null;

       return {
          medicineName,
          brand: resolveField(normalizedRow, FIELD_ALIASES.brand),
          quantity:
            toNumberSafe(
              resolveField(normalizedRow, FIELD_ALIASES.quantity)
            ) || 0,
          price: toNumberSafe(
            resolveField(normalizedRow, FIELD_ALIASES.price)
          ),
          expiry: parseExpiryDate(
            resolveField(normalizedRow, FIELD_ALIASES.expiry)
          ),
        };

      })
      .filter(Boolean);

    const inventory = await Inventory.findOneAndUpdate(
      { pharmacist: req.user.id },
      {
        items: cleanedItems,
        lastUpdatedAt: new Date(),
      },
      { new: true, upsert: true }
    );

    res.json({
      success: true,
      imported: cleanedItems.length,
      inventory,
    });
  } catch (err) {
    console.error("CSV upload failed:", err);
    res.status(500).json({ message: "CSV upload failed" });
  }
};


