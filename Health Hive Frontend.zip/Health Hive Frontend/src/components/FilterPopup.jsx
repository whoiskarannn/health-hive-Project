import React, { useState, useRef } from "react";
import { useNavigate } from "react-router-dom";
import useAutocomplete from "../hooks/useAutocomplete";
import axios from "axios";
import "./css/FilterPopup.css";

/* ================= MAIN FILTER POPUP ================= */

const FilterPopup = ({
  onClose,
  defaultPlace = "",
  defaultCategory = "hospital",
}) => {
  const [category, setCategory] = useState(defaultCategory);
  const [place, setPlace] = useState(defaultPlace);
  const [suggestions, setSuggestions] = useState([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [isValidPlace, setIsValidPlace] = useState(false);
  const [isLoadingLocation, setIsLoadingLocation] = useState(false);
  const [showMedicinePopup, setShowMedicinePopup] = useState(false);

  const navigate = useNavigate();
  const debounceRef = useRef(null);

  /* ================= LOCATION AUTOCOMPLETE ================= */

  const handlePlaceChange = (e) => {
    const value = e.target.value;
    setPlace(value);
    setShowSuggestions(true);
    setIsValidPlace(false);

    if (debounceRef.current) clearTimeout(debounceRef.current);

    if (value.trim().length < 2) {
      setSuggestions([]);
      setIsLoadingLocation(false);
      return;
    }

    setIsLoadingLocation(true);

    debounceRef.current = setTimeout(async () => {
      try {
        const res = await axios.get(
          "https://nominatim.openstreetmap.org/search",
          {
            params: {
              q: value,
              format: "json",
              addressdetails: 1,
              limit: 8,
              countrycodes: "in",
              bounded: 1,
            },
          }
        );
        setSuggestions(res.data);
      } catch (err) {
        console.error("Autocomplete error:", err);
        setSuggestions([]);
      } finally {
        setIsLoadingLocation(false);
      }
    }, 400);
  };

  const handleSuggestionClick = (s) => {
    setPlace(s.display_name);
    setIsValidPlace(true);
    setSuggestions([]);
    setShowSuggestions(false);
  };

  const handleUseMyLocation = () => {
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const coords = `${pos.coords.latitude},${pos.coords.longitude}`;
        setPlace(coords);
        setIsValidPlace(true);
        setSuggestions([]);
        setShowSuggestions(false);
      },
      () => alert("Unable to retrieve location")
    );
  };

  const handleCategoryChange = (value) => {
    if (value === "medicine") setShowMedicinePopup(true);
    else setCategory(value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!isValidPlace) return alert("Please select a valid location");

    navigate(
      `/mappage?place=${encodeURIComponent(place)}&category=${category}`
    );
    onClose();
  };

  const handleClear = () => {
    setCategory("hospital");
    setPlace("");
    setSuggestions([]);
    setShowSuggestions(false);
    setIsValidPlace(false);
  };

  return (
    <>
      {showMedicinePopup ? (
        <MedicineSearchPopup
          place={place}
          onClose={() => setShowMedicinePopup(false)}
        />
      ) : (
        <div className="overlay">
          <div className="popup">
            <button onClick={onClose} className="closeBtn">✕</button>

            <h2>Search Filters</h2>

            <form onSubmit={handleSubmit} className="form">
              <label>What are you looking for?</label>
              <select
                value={category}
                onChange={(e) => handleCategoryChange(e.target.value)}
                className="input"
              >
                <option value="hospital">Hospital</option>
                <option value="clinic">Clinic</option>
                <option value="pharmacy">Medical Store</option>
                <option value="medicine">Find Medicine</option>
              </select>

              <label>Where?</label>
              <div className="inputWrapper">
                <input
                  type="text"
                  value={place}
                  onChange={handlePlaceChange}
                  placeholder="Enter area or town"
                  className="input"
                />

                {showSuggestions && (
                  <ul className="suggestionList">
                    {isLoadingLocation && (
                      <li className="loadingItem">Loading...</li>
                    )}
                    {!isLoadingLocation &&
                      suggestions.map((s, i) => (
                        <li
                          key={i}
                          className="suggestionItem"
                          onClick={() => handleSuggestionClick(s)}
                        >
                          {s.display_name}
                        </li>
                      ))}
                  </ul>
                )}
              </div>

              <button
                type="button"
                onClick={handleUseMyLocation}
                className="buttonSecondary"
              >
                Use My Location
              </button>

              <div className="buttonRow">
                <button type="submit" className="buttonPrimary">Search</button>
                <button
                  type="button"
                  onClick={handleClear}
                  className="buttonSecondary"
                >
                  Clear
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  );
};

/* ================= MEDICINE SEARCH POPUP ================= */

const MedicineSearchPopup = ({ place, onClose }) => {
  const navigate = useNavigate();

  const [medicineQuery, setMedicineQuery] = useState("");
  const [medicine, setMedicine] = useState(null);
  const [medicineSuggestions, setMedicineSuggestions] = useState([]);
  const [showMedicineSuggestions, setShowMedicineSuggestions] = useState(false);
  const [isValidMedicine, setIsValidMedicine] = useState(false);
  const [isLoadingMedicine, setIsLoadingMedicine] = useState(false);
  const [type, setType] = useState("");

  const debounceRef = useRef(null);

  const handleClear = () => {
    setMedicineQuery("");
    setMedicine(null);
    setMedicineSuggestions([]);
    setIsValidMedicine(false);
    setType("");
  };

  const handleMedicineChange = (e) => {
    const value = e.target.value;
    setMedicineQuery(value);
    setIsValidMedicine(false);
    setShowMedicineSuggestions(true);

    if (debounceRef.current) clearTimeout(debounceRef.current);

    if (value.trim().length < 2) {
      setMedicineSuggestions([]);
      setIsLoadingMedicine(false);
      return;
    }

    setIsLoadingMedicine(true);

    debounceRef.current = setTimeout(() => {
      const MOCK_MEDICINES = [
        "Paracetamol",
        "Ibuprofen",
        "Amoxicillin",
        "Cetirizine",
        "Azithromycin",
        "Metformin",
      ];

      setMedicineSuggestions(
        MOCK_MEDICINES.filter((m) =>
          m.toLowerCase().includes(value.toLowerCase())
        )
      );
      setIsLoadingMedicine(false);
    }, 300);
  };

  const handleMedicineSelect = (name) => {
    setMedicine(name);
    setMedicineQuery(name);
    setIsValidMedicine(true);
    setMedicineSuggestions([]);
    setShowMedicineSuggestions(false);
  };

  const handleSubmit = () => {
    if (!isValidMedicine) return alert("Please select a medicine from the list");

    navigate(
      `/mappage?mode=medicine&place=${encodeURIComponent(
        place
      )}&medicine=${encodeURIComponent(medicine)}&type=${type}`
    );
    onClose();
  };

  return (
    <div className="overlay">
      <div className="popup">
        <button onClick={onClose} className="closeBtn">✕</button>

        <h2>Find Medicine</h2>

        <label>Medicine Name</label>
        <div className="inputWrapper">
          <input
            value={medicineQuery}
            onChange={handleMedicineChange}
            onFocus={() => setShowMedicineSuggestions(true)}
            placeholder="Search medicine"
            className="input"
          />

          {showMedicineSuggestions && (
            <ul className="suggestionList">
              {isLoadingMedicine && (
                <li className="loadingItem">Loading...</li>
              )}
              {!isLoadingMedicine &&
                medicineSuggestions.map((m, i) => (
                  <li
                    key={i}
                    className="suggestionItem"
                    onClick={() => handleMedicineSelect(m)}
                  >
                    {m}
                  </li>
                ))}
            </ul>
          )}
        </div>

        <div className="medicineType">
          <label>Medicine Type</label>
          <select
            value={type}
            onChange={(e) => setType(e.target.value)}
            className="input"
          >
            <option value="">Any</option>
            <option value="tablet">Tablet</option>
            <option value="syrup">Syrup</option>
            <option value="injection">Injection</option>
            <option value="powder">Powder</option>
          </select>
        </div>

        <div className="buttonRow">
          <button onClick={handleSubmit} className="buttonPrimary">
            Search Medicine
          </button>
          <button onClick={handleClear} className="buttonSecondary">
            Clear
          </button>
        </div>
      </div>
    </div>
  );
};

export default FilterPopup;
