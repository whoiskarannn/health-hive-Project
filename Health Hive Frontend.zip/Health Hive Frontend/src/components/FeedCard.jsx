import "../QA/QuestionsList.css";

export default function FeedCard({ item }) {
  const currentUser = JSON.parse(localStorage.getItem("user"));

  const poster = item.postedBy || currentUser;

  return (
    <div className="qa-card">
      <h3>{item.title}</h3>

      {item.description && (
        <p className="qa-description">{item.description}</p>
      )}

      {item.content && (
        <p className="qa-description">{item.content}</p>
      )}

    <div className="qa-meta">
      <div className="qa-poster">
        {item.postedBy?.avatar ? (
          <img
            src={item.postedBy.avatar}
            alt={`${item.postedBy.name}'s profile`} 
            className="qa-avatar"
          />
        ) : (
          <div className="qa-avatar fallback">
            <i className="fa-solid fa-user"></i>
          </div>
        )}
        <span className="qa-name">
          {item.postedBy?.name || "Anonymous"}
        </span>
      </div>
    </div>



      <div className="qa-actions">
        <button><i className="fa-regular fa-comment"></i></button>
        <button><i className="fa-solid fa-thumbs-up"></i></button>
        <button><i className="fa-solid fa-thumbs-down"></i></button>
        <button><i className="fa-solid fa-flag"></i></button>
        <button><i className="fa-solid fa-share-nodes"></i></button>
      </div>
    </div>
  );
}
