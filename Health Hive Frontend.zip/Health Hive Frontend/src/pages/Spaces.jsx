import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import "./css/Spaces.css";
import "../components/css/Sidebar.css";
import Navbar from "../components/Navbar";

const SpaceSkeleton = () => (
  <div className="spaces-card spaces-skeleton">
    <div className="spaces-card-icon skeleton-box"></div>
    <div className="spaces-card-title skeleton-box"></div>
    <div className="spaces-card-meta skeleton-box"></div>
    <div className="spaces-card-button skeleton-box"></div>
  </div>
);

function Spaces() {
  const [spaces, setSpaces] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("http://localhost:5000/api/spaces")
      .then((res) => res.json())
      .then((data) => {
        setSpaces(data.filter((s) => s.status === "active"));
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  return (
    <>
    <Navbar />
    <div className="Main_content">
    <div className="spaces-page">
      <h2 className="spaces-title">Explore Communities</h2>

      <div className="spaces-grid">
        {loading
          ? [1, 2, 3, 4, 5].map((i) => <SpaceSkeleton key={i} />)
          : spaces.map((space) => (
              <div key={space._id} className="spaces-card">
                <div className="spaces-card-left">
                  <div className="spaces-card-icon">
                    {space.icon || "📌"}
                  </div>
                </div>

                <div className="spaces-card-content">
                  <span className="spaces-card-title">
                    {space.title}
                  </span>

                  <span className="spaces-card-meta">
                    {(space.visitors || 0).toLocaleString()} weekly visitors
                  </span>

                  <p className="spaces-card-description">
                    {space.description || "No description available."}
                  </p>
                </div>

                <div className="spaces-card-action">
                  <Link
                    to={`/space/${space.slug}`}
                    className="spaces-join-btn"
                  >
                    Join
                  </Link>
                </div>
              </div>
            ))}
      </div>
    </div>
    </div>
    </>
  );
}

export default Spaces;
