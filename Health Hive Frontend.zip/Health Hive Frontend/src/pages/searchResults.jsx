import { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import axios from "axios";
import FeedCard from "../components/FeedCard";
import "../QA/QuestionsList.css";
import Navbar from "../components/Navbar";
import "../components/css/Navbar.css"

export default function SearchResults() {
  const [searchParams] = useSearchParams();
  const query = searchParams.get("q");

  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!query) return;

    const fetchResults = async () => {
      try {
        setLoading(true);
        setError("");

        const res = await axios.get(
          `http://localhost:5000/api/search?q=${encodeURIComponent(query)}`
        );

        setResults(res.data || []);
      } catch (err) {
        console.error(err);
        setError("Search failed");
      } finally {
        setLoading(false);
      }
    };

    fetchResults();
  }, [query]);

  if (loading) {
    return (
        <>
         <Navbar />
        <div className="qa-container">
            <h2 className="qa-title">Searching…</h2>
        </div>
      </>
    );
  }

  if (error) {
    return (
        <>
        <Navbar />
        <div className="qa-container">
            <h2 className="qa-title">{error}</h2>
        </div>
      </>
    );
  }

  return (
    <>
  
  <Navbar />
    <div className="qa-container">
        
      <h2 className="qa-title">
        Search results for “{query}”
      </h2>

      {results.length === 0 ? (
        <p style={{ padding: "1rem" }}>No results found</p>
      ) : (
        results.map(item => (
          <FeedCard key={item._id} item={item} />
        ))
      )}
    </div>
    </>
  );
}
