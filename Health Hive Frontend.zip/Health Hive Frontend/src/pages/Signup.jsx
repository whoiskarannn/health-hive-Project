import { useState } from "react";

const Signup = () => {
  const [role, setRole] = useState("");

  return (
    <div style={{ maxWidth: "400px", margin: "50px auto" }}>
      <h2>Sign Up</h2>

      <select value={role} onChange={(e) => setRole(e.target.value)}>
        <option value="">Select role</option>
        <option value="browse_guest">Browse as Guest</option>
        <option value="guest">Register as Guest</option>
        <option value="student">Student</option>
        <option value="user">Normal User</option>
        <option value="doctor">Doctor</option>
        <option value="pharmacist">Pharmacist</option>
      </select>

      {/* Conditional forms will go here */}
    </div>
  );
};

export default Signup;
