export default function PostCard({ data }) {
  return (
    <div className="post-card">
      <div className="post-author">Guest</div>
      <p className="post-content">{data.content}</p>
      <div className="post-meta">Posted</div>
    </div>
  );
}
