import { useEffect, useState } from "react";
import "./QuestionsList.css";
import FeedCard from "../components/FeedCard";

function Skeleton() {
  return (
    <div className="skeleton-card">
      <div className="skeleton-line skeleton-title"></div>
      <div className="skeleton-line skeleton-desc"></div>
      <div className="skeleton-line skeleton-desc short"></div>

      <div className="skeleton-actions">
        <div className="skeleton-circle"></div>
        <div className="skeleton-circle"></div>
        <div className="skeleton-circle"></div>
        <div className="skeleton-circle"></div>
      </div>
    </div>
  );
}

export default function QuestionsList({ mode = "feed" }) {
  const [questions, setQuestions] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("http://localhost:5000/api/feed")
      .then((res) => res.json())
      .then((data) => {
        setQuestions(data); // save API data here
        setLoading(false);
      })
      .catch((err) => {
        console.error("Error fetching feed:", err);
        setLoading(false);
      });
  }, []);

  if (loading) {
    return (
      <div className="qa-container">
        {/* <h2 className="qa-title">Medical Questions</h2> */}
        {[1, 2, 3].map((i) => (
          <Skeleton key={i} />
        ))}
      </div>
    );
  }

  const filteredItems = questions.filter((item) => {
      if (mode === "questions") return item.type === "questions";
      if (mode === "posts") return item.type === "posts";
      return true;
  });

  return (
    <div className="qa-container">
      {/* <h2 className="qa-title">Your Feed</h2> */}
      
      {/* main component without this no data will be shown */}
      {filteredItems.map(item => (
        <FeedCard key={item._id} item={item} />
      ))}
     
    </div>
  );
}
