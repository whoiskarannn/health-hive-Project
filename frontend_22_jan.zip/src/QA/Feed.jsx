import { useEffect, useState } from "react";
import { fetchFeed } from "../api/feedapi";
import QuestionCard from "../QA/QuestionCard";
import PostCard from "../QA/PostCard";
import QuestionsList from "./QuestionsList";

export default function Feed() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchFeed()
      .then((res) => setItems(res.data))
      .finally(() => setLoading(false));zzz
  }, []);



  if (loading) return <div>Loading feed...</div>;

  return (
   <div>
    {/* <QuestionsList /> */}
   </div>
  );
}


// currently this dile is no longer needed as i have an feed api 
