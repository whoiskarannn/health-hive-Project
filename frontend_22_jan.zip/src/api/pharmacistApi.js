import axios from "axios";

const BASE_URL = "http://localhost:5000/api";

const api = axios.create({
  baseURL: BASE_URL,
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem("token");
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export const fetchMyShop = () => {
  return api.get("/pharmacist/shop");
};

export const fetchInventorySummary = () => {
  return api.get("/inventory/summary");
}

export const updateShopDetails = (shopData) => {
  return api.patch("/pharmacist/shop", shopData);
};

export const submitVerificationDocs = (formData) => {
  return api.post("/pharmacist/upload-documents", formData);
};
