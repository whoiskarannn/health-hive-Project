import axios from "axios";

const pinventorymanagerapi = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || "http://localhost:5000/api",
});

// Automatically attach JWT from localStorage to all admin requests
pinventorymanagerapi.interceptors.request.use((config) => {
  const token = localStorage.getItem("token"); // same token used for admin login
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// fetch all pharmacists, optional filter by status
export const fetchPharmacists = (status) => {
  let url = "/admin/pharmacists";
  if (status) url += `?status=${status}`;
  return pinventorymanagerapi.get(url);
};

// approve a pharmacist shop
export const approvePharmacistShop = (pharmacistId) => {
  return pinventorymanagerapi.patch(`/admin/pharmacists/${pharmacistId}/approve`);
};

// reject a pharmacist shop
export const rejectPharmacistShop = (pharmacistId) => {
  return pinventorymanagerapi.patch(`/admin/pharmacists/${pharmacistId}/reject`);
};

export default pinventorymanagerapi;

