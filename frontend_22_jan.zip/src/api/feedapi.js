import axios from "axios";

z

export const fetchFeed = (data) => {

 return axios.get(`${BASE_URL}/feed`);
}

