import axios from "axios";

const pinventorymanagerapi = axios.create({
  baseURL: "http://localhost:5000/api",
});

// Add JWT token to all requests
pinventorymanagerapi.interceptors.request.use((config) => {
  const token = localStorage.getItem("token");
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});


export default pinventorymanagerapi;


