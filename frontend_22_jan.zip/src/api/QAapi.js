import axios from "axios";

const API_BASE = "http://localhost:5000"; // backend URL

export const createQuestion = (data) => {
  const token = localStorage.getItem("token");
  return axios.post(`${API_BASE}/api/questions`, data, {
    headers: { Authorization: `Bearer ${token}` }
  });
};

export const createPost = (data) => {
  const token = localStorage.getItem("token");
  return axios.post(`${API_BASE}/api/posts`, data, {
    headers: { Authorization: `Bearer ${token}` }
  });
};

