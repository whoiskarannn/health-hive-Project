import "../QA/QuestionsList.css";
import { useState, useEffect,useRef } from "react";
import "./css/FeedCard.css"
import CommentsList from "./CommentsList";
import { Link } from "react-router-dom";

export default function FeedCard({ item }) {
  const [isCommentsOpen, setIsCommentsOpen] = useState(false);
  const [commentText, setCommentText] = useState("");
  const [isDirty, setIsDirty] = useState(false);
  const [showDiscardConfirm, setShowDiscardConfirm] = useState(false);

  const [posting, setPosting] = useState(false);
  const [commentsRefreshKey, setCommentsRefreshKey] = useState(0);
  const token = localStorage.getItem("token");
  const [emojis, setEmojis] = useState([]);
  const clickBuffer = useRef([]);

  const [loading, setLoading] = useState({
    like: false,
    dislike: false,
    share: false,
    flag: false
  });


  // const currentUser = JSON.parse(localStorage.getItem("user"));
  const [stats, setStats] = useState({
    likes: 0,
    dislikes: 0,
    shares: 0,
    flags: 0,
  });


  const basePath = "http://localhost:5000/api/content"; // centralized interaction route
  
  const updateStats = async () => {
    try {
      const res = await fetch(`${basePath}/stats/${item.type}/${item._id}`);
      const data = await res.json();
      setStats(data);
    } catch (err) {
      console.error("Failed to update stats:", err);
    }
  };

  // -------------------- Handle interactions --------------------
  const handleAction = async (action, direction = 1) => {
    try {
      setLoading(prev => ({ ...prev, [action]: true }));

      const res = await fetch(`${basePath}/interact`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
        body: JSON.stringify({
          contentId: item._id,
          contentType: item.type,
          action,
          direction
        }),
      });

      const data = await res.json();

      await updateStats(); // update number from backend

      setTimeout(() => {
        setLoading(prev => ({ ...prev, [action]: false }));
      }, 500); // shorter spinner for testing

      return data; // ✅ return message
    } catch (err) {
      console.error("Action failed", err);
      setLoading(prev => ({ ...prev, [action]: false }));
    }
  };


  //  console.log(item.type, item._id) 
  // -------------------- Fetch stats on mount --------------------
  useEffect(() => {
    const fetchStats = async () => {
      try {
        const res = await fetch(`${basePath}/stats/${item.type}/${item._id}`);
        const data = await res.json();
        setStats(data);
      } catch (err) {
        console.error("Failed to fetch stats", err);
      }
    };

    fetchStats();
  }, [item._id, item.type]);


  // emojies animation ================
  const handleLikeClick = async () => {
    try {
      const res = await handleAction("like"); // wait for backend
      const message = res?.message;

      const now = Date.now();
      clickBuffer.current = clickBuffer.current.filter(t => now - t < 1000);
      clickBuffer.current.push(now);
      const count = clickBuffer.current.length;

      // Spawn multiple emojis if more than 4 clicks, max 5 at a time
      const emojiCount = Math.min(count > 4 ? 5 : 1, 5);

     for (let i = 0; i < emojiCount; i++) {
        const id = Date.now() + Math.random(); // unique
        const offset = Math.floor(Math.random() * 30) - 15; // -15px to +15px

        setEmojis(prev => [...prev, { id, emoji: "👍", offset }]);

        setTimeout(() => {
          setEmojis(prev => prev.filter(e => e.id !== id));
        }, 1000);
      }


      console.log("Like action result:", message);
    } catch (err) {
      console.error("Like click failed", err);
    }
  };


// =================== comment section ====================
  const handleCommentsCloseAttempt = () => {
    if (!isDirty) {
      setIsCommentsOpen(false);
      return;
    }
    setShowDiscardConfirm(true);
  };

// =================== submit comment ====================
  // =================== submit comment ====================
const handleSubmit = async (e) => {
  e.preventDefault();

  // Check if user is logged in
  if (!token) {
    alert("You must be logged in to post a comment");
    return;
  }

  // Prevent empty comments
  if (!commentText.trim()) return;

  try {
    setPosting(true); // disable input

    // POST to backend
    const res = await fetch("http://localhost:5000/api/comments", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`, // attach token
      },
      body: JSON.stringify({
        contentType: item.type,
        contentId: item._id,
        text: commentText,
      }),
    });

    // Read response as text first
    const text = await res.text();
    let data;

    try {
      data = JSON.parse(text); // parse JSON
    } catch {
      console.log("Backend returned non-JSON:", text);
      throw new Error("Invalid response from server");
    }

    if (!res.ok) {
      throw new Error(data.message || "Failed to post comment");
    }

    // Success → update frontend
    setCommentText("");        // clear input
    setIsDirty(false);         // reset dirty state
    setCommentsRefreshKey(prev => prev + 1); // refresh CommentsList

  } catch (err) {
    console.error("Failed to post comment:", err);
    alert(err.message); // show error to user
  } finally {
    setPosting(false); // always re-enable input
  }
};


  // ==========================================================================
    return (
    <div className="qa-card">

      <div className="qa-meta">
        <div className="qa-poster">
            {item.postedBy?.avatar ? (
              <img src={item.postedBy.avatar} alt={`${item.postedBy.name}'s profile`} className="qa-avatar" />
            ) : (
              <div className="qa-avatar fallback">
                <i className="fa-solid fa-user"></i>
              </div>
            )}
          <div>                       
            <span className="qa-name">{item.postedBy?.name || "Anonymous"}</span><br />
            <h3>{item.title}</h3>
            {item.description && <p className="qa-description">{item.description}</p>}
            {item.content && <p className="qa-description">{item.content}</p>}
          </div>  
        </div>
      </div>

         
      <div className="qa-actions">
          <div className="action-item">
            <button 
              onClick={handleLikeClick} 
              disabled={loading.like} 
              className={loading.like ? "active" : ""}
            >
              <i className="fa-solid fa-thumbs-up"></i>
            </button>
            <span style={{color:"var(--color-3)"}}>
              {loading.like ? <i className="fa-solid fa-spinner fa-spin"></i> : stats.likes > 0 && stats.likes}
            </span>
          </div>
          {/* ======================= action buttons ====================================== */}
          <div className="action-item">
              <button
                onClick={() => setIsCommentsOpen(true)}
                className="comment-btn"
              >
                <i className="fa-solid fa-comment"></i>
              </button>
          </div>

          <div className="action-item">
            <button 
              onClick={() => handleAction("dislike")} 
              disabled={loading.dislike} 
              className={loading.dislike ? "active" : ""}
            >
              <i className="fa-solid fa-thumbs-down"></i>
            </button>
            <span style={{color:"var(--color-3)"}}>
              {loading.dislike ? <i className="fa-solid fa-spinner fa-spin"></i> : stats.dislikes > 0 && stats.dislikes}
            </span>
          </div>

          <div className="action-item">
            <button 
              onClick={() => handleAction("share")} 
              disabled={loading.share} 
              className={loading.share ? "active" : ""}
            >
              <i className="fa-solid fa-share-nodes"></i>
            </button>
            <span style={{color:"var(--color-3)"}}>
              {loading.share ? <i className="fa-solid fa-spinner fa-spin"></i> : stats.shares > 0 && stats.shares}
            </span>
          </div>

          <div className="action-item">
            <button 
              onClick={() => handleAction("flag")} 
              disabled={loading.flag} 
              className={loading.flag ? "active" : ""}
            >
              <i className="fa-solid fa-flag"></i>
            </button>
            <span style={{color:"var(--color-3)"}}>
              {loading.flag ? <i className="fa-solid fa-spinner fa-spin"></i> : stats.flags > 0 && stats.flags}
            </span>
          </div>

      </div>

          {/* optoinal emojies animatoin for likes */}
      {/* <div className="emoji-container">
          {emojis.map(e => (
            <span
              key={e.id}
              className="floating-emoji"
              style={{ left: `${50 + e.offset}%` }} // center + offset
            >
              {e.emoji}
            </span>
          ))}

      </div> */}
     

{/* ===================================== */}
      {isCommentsOpen && (
        <div className="comments-popup-overlay">
          <div className="comments-popup">

            {/* Header */}
            <div className="comments-popup-header">
              <h3>Comments</h3>
              <button
                className="comments-close-btn"
                onClick={handleCommentsCloseAttempt}
              >
                ✕
              </button>
            </div>

            {/* Body */}
            <div className="comments-popup-body">

              {/* Scrollable comments */}
              <div className="comments-scroll-area">
                <CommentsList
                  key={commentsRefreshKey}
                  contentType={item.type}
                  contentId={item._id}
                  refreshKey={commentsRefreshKey}
                />
              </div>

              {/* Input bar */}
              <div className="comments-input-bar">
                {token ? (
                  <form onSubmit={handleSubmit}>
                    <input
                      type="text"
                      placeholder="Write a comment..."
                      value={commentText}
                      onChange={(e) => {
                        setCommentText(e.target.value);
                        setIsDirty(true);
                      }}
                      disabled={posting} // disable while posting
                    />
                    <button type="submit" disabled={posting}>
                      {posting ? "Posting..." : "Post"}
                    </button>
                  </form>
                ) : (
                  <Link to="/login" className="comment-login-hint">
                    Log in to comment
                  </Link>
                )}
              </div>


            </div>
          </div>
        </div>
      )}

{/* ===================================== */}
      {showDiscardConfirm && (
        <div className="comments-discard-overlay">
          <div
            className="comments-discard-modal"
            role="dialog"
            aria-modal="true"
          >
            <div className="comments-discard-header">
              <span className="comments-discard-icon">⚠️</span>
              <h3>Discard your comment?</h3>
            </div>

            <p className="comments-discard-text">
              You have an unfinished comment. If you discard it, your text will be lost.
            </p>

            <div className="comments-discard-actions">
              <button
                className="comments-btn-secondary"
                onClick={() => setShowDiscardConfirm(false)}
              >
                Continue writing
              </button>

              <button
                className="comments-btn-danger"
                onClick={() => {
                  setCommentText("");
                  setIsDirty(false);
                  setShowDiscardConfirm(false);
                  setIsCommentsOpen(false);
                }}
              >
                Discard
              </button>
            </div>
          </div>
        </div>
      )}


    </div>
  );
}

