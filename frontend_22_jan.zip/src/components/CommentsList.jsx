import { useEffect, useState } from "react";
import axios from "axios";

export default function CommentsList({ contentType, contentId, refreshKey }) {
  const [comments, setComments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeMenu, setActiveMenu] = useState(null);
  const [editingId, setEditingId] = useState(null);
  const [editText, setEditText] = useState("");
  const [confirmDelete, setConfirmDelete] = useState(null);
  const rawUser = localStorage.getItem("user");
  const currentUser = rawUser ? JSON.parse(rawUser) : null;



  const token = localStorage.getItem("token");
  // const currentUser = JSON.parse(localStorage.getItem("user")); // must contain _id

  /* ---------------- Fetch comments ---------------- */
  const fetchComments = async () => {
    try {
      const res = await axios.get(
        `/api/comments/${contentType}/${contentId}`
      );
      setComments(res.data);
    } catch (err) {
      console.error("Failed to load comments", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    setLoading(true);
    fetchComments();
  }, [contentType, contentId, refreshKey]);

  /* ---------------- Delete comment (OWNER ONLY) ---------------- */
  const handleDelete = async (commentId) => {
  if (!window.confirm("Delete this comment?")) return;

  try {
    const res = await fetch(
      `http://localhost:5000/api/comments/${commentId}`,
      {
        method: "DELETE",
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (!res.ok) {
      // silently fail or log — UI stays untouched
      return;
    }

    // ✅ update UI ONLY after backend success
    setComments(prev => prev.filter(c => c._id !== commentId));
  } catch (error) {
    console.error("Delete comment failed:", error);
  }
};


  /* ---------------- Edit comment (OWNER ONLY) ---------------- */
  const handleEdit = (comment) => {
    setEditingId(comment._id);
    setEditText(comment.text);
    setActiveMenu(null);
  };

  const submitEdit = async (commentId) => {
    if (!token || !editText.trim()) return;

    try {
      const res = await fetch(
        `http://localhost:5000/api/comments/${commentId}`,
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({ text: editText }),
        }
      );

      const updated = await res.json();

      setComments(prev =>
        prev.map(c => (c._id === commentId ? updated : c))
      );

      setEditingId(null);
      setEditText("");
    } catch (err) {
      console.error("Edit failed", err);
    }
  };

  /* ---------------- UI STATES ---------------- */
  if (loading) {
    return <div className="comments-loading">Loading comments…</div>;
  }

  if (!comments.length) {
    return <div className="no-comments">No comments yet</div>;
  }

  /* ---------------- Render ---------------- */
  return (
    <>
    <div className="comments-list">
      {comments.map(comment => {
        const isOwner =
          Boolean(
            currentUser?.id &&
            comment?.userId?._id &&
            String(comment.userId._id) === String(currentUser.id)
          );


        return (
          <div key={comment._id} className="comment-item">

            {/* Avatar */}
            <div className="comment-avatar">
              {comment.userId?.avatar ? (
                <img
                value={comment.userId.name}
                  src={comment.userId.avatar}
                  alt={comment.userId.name}
                />
              ) : (
                <div className="comment-avatar fallback">
                  <i className="fa-solid fa-user"></i>
                </div>
              )}
            </div>

            {/* Body */}
            <div className="comment-body">
          <div className="comment-header">
            <a
              href={`/profile/${comment.userId?._id}`}
              className="comment-author"
            >
              {comment.userId?.name || "User"}
            </a>

            {isOwner ? (
              <div className="comment-menu">
                <i
                  className="fa-solid fa-ellipsis"
                  onClick={() =>
                    setActiveMenu(activeMenu === comment._id ? null : comment._id)
                  }
                />

                {activeMenu === comment._id && (
                  <div className="comment-dropdown">
                    <button onClick={() => handleEdit(comment)}>Edit</button>
                    <button onClick={() => handleDelete(comment._id)}>Delete</button>
                  </div>
                )}
              </div>
            ) : (
              <a
                href={`/profile/${comment.userId?._id}`}
                className="comment-profile-link"
              >
                View profile
              </a>
            )}
          </div>



              {/* Text / Edit mode */}
              {editingId === comment._id ? (
                <div className="comment-edit">
                  <input
                    value={editText}
                    onChange={e => setEditText(e.target.value)}
                  />
                  <button onClick={() => submitEdit(comment._id)}>
                    Save
                  </button>
                  <button onClick={() => setEditingId(null)}>
                    Cancel
                  </button>
                </div>
              ) : (
                <p className="comment-text">{comment.text}</p>
              )}
            </div>
          </div>
        );
      })}
    </div>
      {confirmDelete && (
      <div className="confirm-overlay">
        <div className="confirm-modal">
          <h3>Delete comment?</h3>
          <p>This action cannot be undone.</p>

          <div className="confirm-actions">
            <button
              className="btn-cancel"
              onClick={() => setConfirmDelete(null)}
            >
              Cancel
            </button>
            <button
              className="btn-danger"
              onClick={() => handleDelete(confirmDelete)}
            >
              Delete
            </button>
          </div>
        </div>
      </div>
    )}

    </>
  );
}
