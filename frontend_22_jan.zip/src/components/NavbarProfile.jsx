import { useState, useEffect, useRef } from "react";
import { Link, useNavigate } from "react-router-dom";
import { getPUser } from "../api/authapi";
import "./css/NavbarProfile.css";
import logout from "../utils/logout.js";

export default function NavbarProfile() {
  const user = getPUser();
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();
  const dropdownRef = useRef(null);

  useEffect(() => {
    if (!open) return;

    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setOpen(false);
      }
    };

    const handleEsc = (e) => {
      if (e.key === "Escape") setOpen(false);
    };

    document.addEventListener("mousedown", handleClickOutside);
    document.addEventListener("keydown", handleEsc);

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
      document.removeEventListener("keydown", handleEsc);
    };
  }, [open]);

  if (!user) return null;

  return (
    <div className="profile-wrapper" ref={dropdownRef}>
      <button className="profile-btn" onClick={() => setOpen(!open)}>
        {user.avatar ? (
          <img
            title="Profile"
            src={user.avatar}
            alt={`${user.name}'s profile`}
            className="profile-avatar"
          />
        ) : (
          <div className="profile-avatar fallback">
            <i className="fa-solid fa-user"></i>
          </div>
        )}
      </button>

      {open && (
        <div className="profile-dropdown">
          <Link>Logged in as: {user.name}</Link>
          <Link to="/profile">My Profile</Link>
          <Link to="/subscriptions">My Subscriptions</Link>
          <Link to="/comments">My Comments</Link>
          <hr />

          {user.role === "pharmacist" ? (
            <Link to="/p-dashboard" className="profile-link">
              Dashboard
            </Link>
          ) : (
            <span className="profile-link disabled">
              Dashboard (Pharmacists only)
            </span>
          )}

          <button
            className="logout-btn"
            onClick={() => logout(navigate)}
          >
            Logout
          </button>
        </div>
      )}
    </div>
  );
}
