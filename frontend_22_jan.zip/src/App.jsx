import { Routes, Route } from "react-router-dom";
import { useEffect } from "react";
// import "leaflet/dist/leaflet.css";
import Home from "./pages/home.jsx";
import SpacePage from "./components/SpacePage.jsx";
import CreateSpace from './pages/CreatreSpace.jsx'
import MapPage from "./pages/MapPage.jsx";
import NotFound from "./components/NotFound.jsx";
import QuestionsList from "./QA/QuestionsList.jsx";
import AskPost from "./QA/AskPost.jsx";
import SearchResults from "./pages/searchResults.jsx";
import Answers from "./pages/Answers.jsx";
import Navbar from "./components/Navbar.jsx";   // not needed for now
import Register from "./pages/Register.jsx";
import VerifyEmail from "./pages/VerifyEmail.jsx";
import Profile from "./pages/Ptofile.jsx";
import Login from "./pages/Login.jsx";
import AuthRequiredModal from "./components/AuthRequiredModal.jsx";
import Spaces from "./pages/Spaces.jsx";

// Pharmacists pages and their routes =============================
import PharmacistInventoy from "./pages/pharmaCorner/P_inventory_manager.jsx";
import PharmacistHomePage from "./pages/pharmaCorner/P_dashboard.jsx";
import P_editShop from "./pages/pharmaCorner/P_editShop.jsx";
import P_shopSettings from "./pages/pharmaCorner/P_shopSettings.jsx";
import PharmacistInventoryGuard from "./pages/pharmaCorner/P_inventoryguard";
import P_shopVerification from "./pages/pharmaCorner/P_shopVerification";
// import dashbord from "./pages/DashBord.jsx"
import AdminDashboard from "./pages/Admin/AdminDashboard.jsx";
import AdminLogin from "./pages/Admin/AdminLogin.jsx";
import PharmacistDetails from "./pages/pharmaCorner/PharmacistDetails.jsx";

function App() {
  useEffect(() => {
    const theme = localStorage.getItem("theme");
    if (theme) {
      document.documentElement.setAttribute("data-theme", theme);
    }
  }, []);


  return (
    <Routes>
      <Route path="/" element={<Home />} />
      {/* Authentication and protected routes ====================== */}
      <Route path="/register" element={<Register />} />
      <Route path="/verify-email" element={<VerifyEmail />} />
      <Route path="/login" element={<Login />} />
      <Route path="/profile" element={<AuthRequiredModal ><Profile /></AuthRequiredModal >} />
      
      <Route path="/create-space" element={<CreateSpace />} />
      <Route path="/spaces" element={<Spaces />}/>
      <Route path="/mappage" element={<MapPage />} />

      {/* <Route path="/navbar" element={<Navbar />}/> */}
      <Route path="/QA" element={<QuestionsList />} />
      <Route path="/QA/ask" element={<AskPost />} />
      <Route path="/QA/answer" element={<Answers />} />

      <Route path="/search" element={<SearchResults />} />
      {/* <Route path="/space/:slug" element={<SpacePage />} /> */}
      {/* pharmacist routes ============================================ */}
      <Route path="/my-p-inventory" element={<PharmacistInventoryGuard><PharmacistInventoy /></PharmacistInventoryGuard>}/>
      <Route path="/p-dashboard" element={<PharmacistInventoryGuard><PharmacistHomePage /></PharmacistInventoryGuard>}/>
      <Route path="/p-dashboard/shop/edit" element={<PharmacistInventoryGuard><P_editShop /></PharmacistInventoryGuard>}/>
      <Route path="/p-dashboard/shop/shopSettings" element={<PharmacistInventoryGuard><P_shopSettings /></PharmacistInventoryGuard>}/>
      <Route path="/p-dashboard/shop/verification" element={<PharmacistInventoryGuard><P_shopVerification /></PharmacistInventoryGuard>} />
      <Route path="/admin/pharmacist/:id" element={<PharmacistDetails/>}/>

      {/* Route for Admin */}
      <Route path="/admin" element={<AdminDashboard />} />
      <Route path="/admin/login" element={<AdminLogin />} />

      <Route path="*" element={<NotFound />} />
    </Routes>


  );
}

export default App;
