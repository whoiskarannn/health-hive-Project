import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { fetchMyShop, updateShopDetails } from "../../api/pharmacistApi.js";
import { getPUser } from "../../api/authapi";
import "./P_editShop.css";

const P_editShop = () => {
  const navigate = useNavigate();

  const [shop, setShop] = useState(null);

  const [name, setName] = useState("");
  const [address, setAddress] = useState("");
  const [email, setEmail] = useState("");

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [toast, setToast] = useState("");

  // confirmation popup
  const [showConfirm, setShowConfirm] = useState(false);

  // ✅ Load shop from backend
  useEffect(() => {
    const loadShop = async () => {
      try {
        const res = await fetchMyShop();
        const shopData = res.data.shop;

        setShop(shopData);
        setName(shopData?.name || "");
        setAddress(shopData?.address || "");
        setEmail(shopData?.email || "");
      } catch (err) {
        console.error("Failed to load shop for edit", err);
      }
    };

    loadShop();
  }, []);

  // ⛔ BACKEND LOGIC UNTOUCHED
  const handleSubmit = async () => {
    setError("");
    setToast("");

    if (!name.trim() || !address.trim() || !email.trim()) {
      setError("All fields are required");
      return;
    }

    try {
      setLoading(true);

      const res = await updateShopDetails({ name, address, email });

      // Update localStorage
      const currentUser = getPUser();
      const updatedUser = {
        ...currentUser,
        shop: res.data.user.shop,
      };
      localStorage.setItem("user", JSON.stringify(updatedUser));

      window.dispatchEvent(new Event("user-updated"));

      setToast("✅ Shop updated successfully!");
      setShowConfirm(false);

      setTimeout(() => navigate("/p-dashboard"), 1200);
    } catch (err) {
      console.error(err);
      setError(err.response?.data?.message || "Failed to update shop");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="edit-shop-page">
      <h2>Edit Shop Details</h2>

      <div className="edit-card">
        {/* ❌ form no longer auto-submits */}
        <form>
          <div className="form-group">
            <label>
              Shop Name: <strong>{shop?.name || "—"}</strong>
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Enter new shop name"
            />
          </div>

          <div className="form-group">
            <label>
              Shop Email: <strong>{shop?.email || "—"}</strong>
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Enter new shop email"
            />
          </div>

          <div className="form-group">
            <label>
              Address: <strong>{shop?.address || "—"}</strong>
            </label>
            <input
              type="text"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder="Enter new address"
            />
          </div>

          <div
            style={{
              display: "flex",
              gap: "80px",
              alignItems: "center",
              marginTop: "8px",
              justifyContent: "space-between",
            }}
          >
            {/* ✅ Save only opens popup */}
            <button
              type="button"
              className="save-btn"
              disabled={loading}
              onClick={() => setShowConfirm(true)}
            >
              {loading ? "Saving..." : "Save"}
            </button>

            <Link className="Link" to="/p-dashboard">
              Exit
            </Link>
          </div>
        </form>

        {error && <p style={{ color: "red" }}>{error}</p>}
        {toast && <div className="toast-popup">{toast}</div>}
      </div>

      {/* ================= CONFIRM POPUP ================= */}
      {showConfirm && (
        <div className="confirm-overlay">
          <div className="confirm-box">
            <p>Are you sure you want to update your shop details?</p>

            <div className="confirm-actions">
              <button
                className="save-btn"
                disabled={loading}
                onClick={handleSubmit}
              >
                Yes, Update
              </button>

              <button
                className="secondary-btn"
                onClick={() => setShowConfirm(false)}
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
      {/* ================================================ */}
    </div>
  );
};

export default P_editShop;
