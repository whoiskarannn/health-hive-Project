import { useState } from "react";
import { submitVerificationDocs } from "../../api/pharmacistApi";
import "./P_shopVerification.css";

export default function P_shopVerification() {
  const [files, setFiles] = useState({
    pharmacyLicense: null,
    ownerIdProof: null,
    gstCertificate: null,
  });

  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");

  const handleChange = (e) => {
    const { name, files: selectedFiles } = e.target;
    setMessage("");
    setFiles((prev) => ({
      ...prev,
      [name]: selectedFiles[0] || null,
    }));
  };

  const submitDocuments = async (e) => {
    e.preventDefault();
    if (loading) return;

    if (!files.pharmacyLicense || !files.ownerIdProof) {
      setMessage("Pharmacy License and Owner ID Proof are required.");
      return;
    }

    const formData = new FormData();
    Object.entries(files).forEach(([key, file]) => {
      if (file) formData.append(key, file);
    });

    try {
      setLoading(true);
      await submitVerificationDocs(formData);
      setMessage("Documents submitted successfully. Verification pending.");

      setFiles({
        pharmacyLicense: null,
        ownerIdProof: null,
        gstCertificate: null,
      });
    } catch (err) {
      setMessage(
        err.response?.data?.message || "Failed to submit documents."
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="page">
      <h3>Shop Verification</h3>
      <form className="doc-upload" onSubmit={submitDocuments}>
        <input type="file" name="pharmacyLicense" onChange={handleChange} />
        <input type="file" name="ownerIdProof" onChange={handleChange} />
        <input type="file" name="gstCertificate" onChange={handleChange} />
        <button disabled={loading}>Submit</button>
        {message && <p>{message}</p>}
      </form>
    </div>
  );
}
