import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import pinventorymanagerapi from "../../api/pinventorymanagerapi";
import "./PharmacistDetails.css";

const API_BASE = "http://localhost:5000";

const PharmacistDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const [pharmacist, setPharmacist] = useState(null);
  const [activeDocument, setActiveDocument] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  /* =======================
     FETCH PHARMACIST
  ======================= */
  useEffect(() => {
    const fetchPharmacist = async () => {
      try {
        const res = await pinventorymanagerapi.get(
          `/admin/pharmacist/${id}`
        );
        setPharmacist(res.data.pharmacist);
      } catch (err) {
        console.error(err);
        if (err.response?.status === 401) navigate("/admin/login");
        else setError("Failed to load pharmacist");
      } finally {
        setLoading(false);
      }
    };

    fetchPharmacist();
  }, [id, navigate]);

  if (loading) return <p style={{ padding: "2rem" }}>Loading…</p>;
  if (error) return <p style={{ color: "red", padding: "2rem" }}>{error}</p>;
  if (!pharmacist) return null;

  /* =======================
     STATUS
  ======================= */
  const status = pharmacist.shop?.verificationStatus || "unverified";
  const statusClass = `status-${status}`;

  /* =======================
     DOCUMENTS
  ======================= */
  const documents = Object.entries(pharmacist.shop?.documents || {})
    .filter(([, doc]) => doc?.url)
    .map(([key, doc]) => ({
      key,
      url: doc.url.startsWith("http")
        ? doc.url
        : `${API_BASE}${doc.url}`,
    }));

  const hasDocuments = documents.length > 0;

  /* =======================
     STATUS UPDATE (FIXED)
  ======================= */
  const updateStatus = async (action) => {
    try {
      if (action === "approve") {
        await pinventorymanagerapi.patch(
          `/admin/pharmacists/${id}/approve`
        );

        setPharmacist((prev) => ({
          ...prev,
          shop: {
            ...prev.shop,
            verificationStatus: "verified",
          },
        }));
      }

      if (action === "reject") {
        await pinventorymanagerapi.patch(
          `/admin/pharmacists/${id}/reject`
        );

        setPharmacist((prev) => ({
          ...prev,
          shop: {
            ...prev.shop,
            verificationStatus: "rejected",
          },
        }));
      }
    } catch (err) {
      console.error(err);
      alert("Failed to update status");
    }
  };

  return (
    <section className="Main_Page_container">
      <div className="pharmacist-page">
        <header className="pharmacist-header">
          <h1>Pharmacist Details</h1>
          <button className="back-btn" onClick={() => navigate("/admin")}>
            ← Back
          </button>
        </header>

        <div className="pharmacist-grid">
          <div className="info-card">
            <span className={`status-badge ${statusClass}`}>
              {status}
            </span>

            <h2>Personal Info</h2>
            <div className="info-row"><strong>Name:</strong> {pharmacist.name}</div>
            <div className="info-row"><strong>Email:</strong> {pharmacist.email}</div>
            <div className="info-row"><strong>Role:</strong> {pharmacist.role}</div>

            <h2>Shop Info</h2>
            <div className="info-row"><strong>Name:</strong> {pharmacist.shop?.name}</div>
            <div className="info-row"><strong>Email:</strong> {pharmacist.shop?.email}</div>
            <div className="info-row"><strong>Address:</strong> {pharmacist.shop?.address}</div>

            <h2>Documents</h2>
            {!hasDocuments ? (
              <div className="no-documents">🔔 No documents uploaded</div>
            ) : (
              <ul className="documents-list">
                {documents.map((doc) => (
                  <li key={doc.key}>
                    <strong>{doc.key}</strong>{" "}
                    <button
                      className="link-btn"
                      onClick={() => setActiveDocument(doc)}
                    >
                      View
                    </button>
                  </li>
                ))}
              </ul>
            )}

            <div className="action-buttons">
              <button
                className="btn approve"
                disabled={!hasDocuments || status === "verified"}
                onClick={() => updateStatus("approve")}
              >
                Approve
              </button>

              <button
                className="btn reject"
                disabled={!hasDocuments || status === "rejected"}
                onClick={() => updateStatus("reject")}
              >
                Reject
              </button>
            </div>
          </div>
        </div>

        {/* DOCUMENT MODAL */}
        {activeDocument && (
          <div
            className="modal-overlay"
            onClick={() => setActiveDocument(null)}
          >
            <div
              className="modal-content"
              onClick={(e) => e.stopPropagation()}
            >
              <button
                className="modal-close"
                onClick={() => setActiveDocument(null)}
              >
                ×
              </button>

              {activeDocument.url.toLowerCase().endsWith(".pdf") ? (
                <iframe
                  src={activeDocument.url}
                  title="Document"
                  className="modal-doc-viewer"
                />
              ) : (
                <img
                  src={activeDocument.url}
                  alt="Document"
                  className="modal-doc-viewer"
                />
              )}
            </div>
          </div>
        )}
      </div>
    </section>
  );
};

export default PharmacistDetails;
