import { Navigate , Link } from "react-router-dom";
import Navbar from "../../components/Navbar";
import P_news from "./P_news";
import P_shop from "./P_shop";
import { getPUser } from "../../api/authapi";
import "./P_dashboard.css"

const p_dashboard = () => {
  const user = getPUser();


  return (
    <>
      <Navbar />

      <div className="home-dashboard">
        <h2 className="dashboard-title">Dashboard</h2>

        
          <div className="inside-section">
            <P_shop />
            <P_news />
          </div>
        
        {user.shop?.verificationStatus !== "verified" && (
          <div className="setup-warning">
            {user.shop?.verificationStatus === "pending"
              ? "Your documents are under verification."
              : "Complete your shop verification to manage inventory."}

            <Link to="/p-dashboard/shop/verification">
              View verification
            </Link>
          </div>
        )}

      </div>
    </>
  );
};

export default p_dashboard;
