import { useEffect, useState } from "react";
import { fetchMyShop,fetchInventorySummary } from "../../api/pharmacistApi";
import { getPUser } from "../../api/authapi";
import { Link, useNavigate } from "react-router-dom";
import "./P_shop.css";

const P_shop = () => {
  const navigate = useNavigate();
  const user = getPUser();
  const [inventoryStats, setInventoryStats] = useState({
    totalMedicines: 0,
    lowStock: 0,
  });


  // 🚫 Only pharmacists can access
  // useEffect(() => {
  //   if (!user || user.role !== "pharmacist") {
  //     navigate("/login"); // redirect non-pharmacist users
  //   }
  // }, [user, navigate]);

  const [shop, setShop] = useState(user?.shop || null);
  const [loading, setLoading] = useState(!user?.shop);

    useEffect(() => {
    if (!shop || shop.verificationStatus !== "verified") {
      setInventoryStats({ totalMedicines: 0, lowStock: 0 });
      return;
    }

    const loadInventoryStats = async () => {
      try {
        const { data } = await fetchInventorySummary();
        setInventoryStats(data);
      } catch (err) {
        console.error("Failed to fetch inventory summary", err);
      }
    };

    loadInventoryStats();
  }, [shop]);


  useEffect(() => {
    if (!user || user.role !== "pharmacist") {
      navigate("/login");
      return;
    }

    const loadShop = async () => {
      try {
        const res = await fetchMyShop();
        setShop(res.data.shop);
      } catch (err) {
        console.error("Failed to load shop", err);
      } finally {
        setLoading(false);
      }
    };

    loadShop();

    const interval = setInterval(loadShop, 5000); // auto-refresh every 5s

    return () => clearInterval(interval);
  }, [user, navigate]);


  if (loading) return <p style={{ padding: "2rem" }}>Loading...</p>;
  if (!user) return null; // safety

  const verificationStatusText = () => {
    switch (shop?.verificationStatus) {
      case "pending": return "Pending verification";
      case "verified": return "Verified ✅";
      case "rejected": return "Rejected ";
      default: return "Not verified";
    }
  };

  
  return (
    <div className="shop-wrapper">
      <section className="shop-card">
        {!shop ? (
          // 🚨 No shop created yet
          <div className="no-shop">
            <p>You have not created a shop yet.</p>
            <Link to="/p-dashboard/shop/edit" className="primary-btn">
              Create Shop
            </Link>
          </div>
        ) : (
          <>
            <div className="shop-header">
              <h2 className="shop-name">
                {shop.name}
                <Link to="/p-dashboard/shop/edit" className="secondary-btn">
                  Edit Shop Details
                </Link>
              </h2>
              
              <span
                className={`status-badge-shop status-${shop?.verificationStatus || "unverified"}`}
                title={verificationStatusText()}
              >
                {verificationStatusText()}
              </span>

            </div>

            <div className="shop-info">
              <p><strong>Address:</strong> {shop.address || "Not provided"}</p>
              <p><strong>Email:</strong> {shop.email || "Not provided"}</p>
            </div>

            <div className="shop-stats">
              <div>
                <strong>{inventoryStats.totalMedicines}</strong>
                <span>Total Medicines</span>
              </div>
              <div>
                <strong>{inventoryStats.lowStock}</strong>
                <span>Low Stock</span>
              </div>
            </div>

            <hr style={{ width: "100%" }} />

            {shop.verificationStatus === "unverified" && (
              <div className="verification-box">
                <p>
                  Your shop is <strong style={{ textDecoration: "underline" }}>not verified yet</strong>. 
                  Upload <strong style={{ textDecoration: "underline" }}>Verification documents</strong> to proceed.
                </p>
                <Link to="/p-dashboard/shop/verification" className="secondary-btn">
                  Upload Documents
                </Link>
              </div>
            )}

            <Link
              title="My Inventory"
              to={shop.verificationStatus === "verified" ? "/my-p-inventory" : "#"}
              className={`primary-btn ${
                shop.verificationStatus !== "verified" ? "btn-disabled" : ""
              }`}
              onClick={(e) => {
                if (shop.verificationStatus !== "verified") e.preventDefault();
              }}
            >
              Manage Inventory →
            </Link>
          </>
        )}

                {/*===================================*/}
                {!shop?.setupCompleted && shop && (
                  <div className="setup-warning">
                    Complete your shop setup{" "}
                    <Link to="/p-dashboard/shop/verification">Complete Setup</Link>
                  </div>
                )}
                {/*===================================*/}
      </section>
    </div>
  );
};

export default P_shop;
