import { Navigate } from "react-router-dom";
import { getPUser } from "../../api/authapi";

function PharmacistInventoryGuard({ children }) {
  const user = getPUser();

  if (!user || user.role !== "pharmacist") {
    return (
      <Navigate
        to="/login"
        // replace
        // state={{ authMessage: "Please log in as a pharmacist to gain access." }}
      />
    );
  }

  return children;
}


export default PharmacistInventoryGuard;
