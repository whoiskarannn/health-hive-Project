import React, { useEffect, useState } from "react";
import { Navigate, useNavigate } from "react-router-dom";
import pinventorymanagerapi from "../../api/pinventorymanagerapi.js";
import "./AdminDashboard.css"; // your CSS
import Navbar from "../../components/Navbar.jsx";



export default function AdminDashboard() {
  const user = JSON.parse(localStorage.getItem("admin"));

  const [pharmacists, setPharmacists] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const navigate = useNavigate();
  const [blurEnabled, setBlurEnabled] = useState(() => {
      const saved = localStorage.getItem("adminBlurMode");
      return saved ? JSON.parse(saved) : true;
    });
if (!user) {
  return (
     <Navigate
        to="/admin/login"
        replace
        state={{ message1: "Please log in as a pharmacist to gain access." }}
      />
  )}


    useEffect(() => {
      localStorage.setItem("adminBlurMode", JSON.stringify(blurEnabled));
    }, [blurEnabled]);
  
  // Check admin login
  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) {
      navigate("/admin/login");
    }
  }, [navigate]);

  // Fetch pharmacists
// Fetch pharmacists
const fetchPharmacists = async () => {
  try {
    setLoading(true);
    const token = localStorage.getItem("token");
    if (!token) {
      navigate("/admin/login");
      return;
    }

    const res = await pinventorymanagerapi.get("/admin/pharmacists", {
      headers: { Authorization: `Bearer ${token}` },
    });

    console.log("Pharmacists API response:", res.data);

    const normalized = (res.data.pharmacists || []).map((p) => ({
      ...p,
      shop: p.shop || {},
      shopDocuments: p.shop?.documents || {},
    }));

    setPharmacists(normalized);
    setError("");
  } catch (err) {
    console.error(err);
    if (err.response?.status === 401) {
      localStorage.removeItem("token");
      localStorage.removeItem("admin");
      navigate("/admin/login");
    } else {
      setError(err.response?.data?.message || "Failed to load pharmacists");
      setPharmacists([]);
    }
  } finally {
    setLoading(false);
  }
};


useEffect(() => {
  fetchPharmacists();
}, []);


  const handleViewDetails = (id) => {
    if (!id) return alert("Invalid pharmacist ID");
    navigate(`/admin/pharmacist/${id}`);
  };

  return (
    <>
    <Navbar />
        <button
            className="blur-toggle-btn"
            onClick={() => setBlurEnabled((v) => !v)}
          >
            {blurEnabled ? "Disable focus blur" : "Enable focus blur"}
          </button>

         
    <div className="a-dash-board">
      <div className="admin-header">
        <h1>Admin Dashboard</h1>
        <p>Total pharmacists: {pharmacists?.length || 0}</p><p style={{opacity:"40%"}}>(who created a shop)</p>
      </div>

      {loading && <p>Loading pharmacists...</p>}
      {error && <p style={{ color: "var(--color-red)" }}>{error}</p>}
      <section className="a-dash-main-content">
        {!loading && !error && (
          <div className={`admin-cards ${blurEnabled ? "blur-mode" : ""}`}>
            {pharmacists.map((p) => (
              <div key={p._id} className="admin-card">
                <span
                    className={`status-badge ${
                      p.shop?.verificationStatus === "pending"
                        ? "status-pending"
                        : p.shop?.verificationStatus === "verified"
                        ? "status-verified"
                         : p.shop?.verificationStatus === "rejected"
                        ? "status-rejected"
                        : "status-unverified"
                    }`}
                  >
                    {p.shop?.verificationStatus || "unverified"}
                  </span>
                <h2>Name : {p.name}</h2>
                <p><strong>Email:</strong> {p.email}</p>
                <p><strong>Shop Name:</strong> {p.shop?.name || "N/A"}</p>
                <p><strong>Shop Email:</strong> {p.shop?.email || "N/A"}</p>
                <p><strong>Shop Address:</strong> {p.shop?.address || "N/A"}</p>
                <p>
                  
                </p>
                <button
                  className="action-btn action-approve"
                  onClick={() => handleViewDetails(p._id)}
                >
                  View Details
                </button>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
    </>
  );
};

