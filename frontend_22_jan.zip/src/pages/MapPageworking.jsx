import React, { useEffect, useRef, useState, useMemo } from "react";
import { useSearchParams, Link } from "react-router-dom";
import axios from "axios";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import "leaflet.markercluster";
import "leaflet.markercluster/dist/MarkerCluster.css";
import "leaflet.markercluster/dist/MarkerCluster.Default.css";
import "./css/MapPage.css";

/* ================= ICON HELPERS ================= */
const faMarker = (iconClass, color) =>
  L.divIcon({
    html: `<div class="animated-marker" style="background:${color};width:36px;height:36px;border-radius:50% 50% 50% 0;transform:rotate(-45deg);position:relative">
      <i class="${iconClass}" style="color:white;font-size:16px;position:absolute;top:8px;left:9px;transform:rotate(45deg)"></i>
    </div>`,
    iconSize: [36, 36],
    iconAnchor: [18, 36],
    className: "",
  });


const ICONS = {
  center: faMarker("fa-solid fa-location-dot", "#facc15"),
  hospital: faMarker("fa-solid fa-hospital", "#dc2626"),
  clinic: faMarker("fa-solid fa-user-doctor", "#16a34a"),
  pharmacy: faMarker("fa-solid fa-square-plus", "#7c3aed"),
};

const CATEGORY_OPTIONS = [
  { key: "hospital", label: "Hospitals", icon: "fa-hospital" },
  { key: "clinic", label: "Clinics", icon: "fa-user-doctor" },
  { key: "pharmacy", label: "Pharmacy", icon: "fa-square-plus" },
];

const DEFAULT_RADIUS = 2500;
const DEFAULT_PLACE = "Mumbai";
const CLUSTER_DISABLE_ZOOM = 16;

/* ================= MAIN ================= */
export default function MapPage() {
  const [params, setSearchParams] = useSearchParams();

  const [previewCoords, setPreviewCoords] = useState(null);
  const [searchCoords, setSearchCoords] = useState(null);
  const [radius, setRadius] = useState(DEFAULT_RADIUS);
  const [currentAddress, setCurrentAddress] = useState(null);

  const [allPOIs, setAllPOIs] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState(
    params.get("category") || "hospital"
  );

  const [areaDirty, setAreaDirty] = useState(false);
  const [showHint, setShowHint] = useState(false);
  const [loadingPOIs, setLoadingPOIs] = useState(false);

  /* ================= REFS ================= */
  const mapRef = useRef(null);
  const centerMarkerRef = useRef(null);
  const circleRef = useRef(null);
  const clusterRef = useRef(null);
  const markerCache = useRef(new Map());
  const routeRef = useRef(null);


  /* ================= URL INIT ================= */
  useEffect(() => {
    if (!params.get("lat") && !params.get("place")) {
      setSearchParams({ place: DEFAULT_PLACE, category: "hospital" });
    }
  }, []);

  /* ================= INITIAL GEO ================= */
  useEffect(() => {
    const lat = params.get("lat");
    const lon = params.get("lon");
    const place = params.get("place");

    if (lat && lon) {
      const coords = { lat: +lat, lon: +lon };
      setPreviewCoords(coords);
      setSearchCoords(coords);
      return;
    }

    if (!place) return;

    axios
      .get("https://nominatim.openstreetmap.org/search", {
        params: { q: place, format: "json", limit: 1 },
      })
      .then((res) => {
        if (!res.data?.[0]) return;
        const coords = {
          lat: +res.data[0].lat,
          lon: +res.data[0].lon,
        };
        setPreviewCoords(coords);
        setSearchCoords(coords);
      });
  }, [params]);

  /* ================= MAP INIT ================= */
  useEffect(() => {
    if (!searchCoords || mapRef.current) return;

    const map = L.map("map").setView(
      [searchCoords.lat, searchCoords.lon],
      13
    );
    mapRef.current = map;

    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      attribution: "© OpenStreetMap",
    }).addTo(map);

    clusterRef.current = L.markerClusterGroup({
      disableClusteringAtZoom: CLUSTER_DISABLE_ZOOM,
    });
    map.addLayer(clusterRef.current);

    return () => {
      map.remove();
      mapRef.current = null;
      clusterRef.current = null;
      centerMarkerRef.current = null;
      circleRef.current = null;
      markerCache.current.clear();
    };
  }, [searchCoords]);

  /* ================= PREVIEW MARKER ================= */
  useEffect(() => {
    if (!mapRef.current || !previewCoords) return;

    if (!centerMarkerRef.current) {
      centerMarkerRef.current = L.marker(previewCoords, {
        draggable: true,
        icon: ICONS.center,
      }).addTo(mapRef.current);

      centerMarkerRef.current.on("dragend", (e) => {
        const { lat, lng } = e.target.getLatLng();
        setPreviewCoords({ lat, lon: lng });
        setAreaDirty(true);
        setShowHint(true);

          // Remove old route
        if (routeRef.current) {
          mapRef.current.removeLayer(routeRef.current);
          routeRef.current = null;
        }
      });
    } else {
      centerMarkerRef.current.setLatLng(previewCoords);
    }

    if (!circleRef.current) {
      circleRef.current = L.circle(previewCoords, {
        radius,
        color: "#2563eb",
        fillOpacity: 0.2,
      }).addTo(mapRef.current);
    } else {
      circleRef.current.setLatLng(previewCoords).setRadius(radius);
    }
  }, [previewCoords, radius]);

  /* ================= SEARCH COMMIT ================= */
  const handleSearchThisArea = () => {
    setSearchCoords(previewCoords);
    setAreaDirty(false);
    setShowHint(false);

    setSearchParams({
      lat: previewCoords.lat.toFixed(6),
      lon: previewCoords.lon.toFixed(6),
      category: selectedCategory,
    });
  };

  const handleGoBack = () => {
    setPreviewCoords(searchCoords);
    setAreaDirty(false);
    setShowHint(false);
  };

  /* ================= REVERSE GEO ================= */
  useEffect(() => {
    if (!searchCoords) return;

    setCurrentAddress(null);
    axios
      .get("https://nominatim.openstreetmap.org/reverse", {
        params: {
          lat: searchCoords.lat,
          lon: searchCoords.lon,
          format: "json",
        },
      })
      .then((res) => setCurrentAddress(res.data?.display_name || null));
  }, [searchCoords]);

  /* ================= POI FETCH (ONCE) ================= */
  useEffect(() => {
    if (!searchCoords) return;

    setLoadingPOIs(true);
    markerCache.current.clear();
    clusterRef.current?.clearLayers();

    const query = `
      [out:json][timeout:10];
      (
        node["amenity"="hospital"](around:${DEFAULT_RADIUS},${searchCoords.lat},${searchCoords.lon});
        node["amenity"="clinic"](around:${DEFAULT_RADIUS},${searchCoords.lat},${searchCoords.lon});
        node["amenity"="pharmacy"](around:${DEFAULT_RADIUS},${searchCoords.lat},${searchCoords.lon});
      );
      out;
    `;

    axios
      .post(
        "https://overpass.kumi.systems/api/interpreter",
        new URLSearchParams({ data: query })
      )
      .then((res) => setAllPOIs(res.data?.elements || []))
      .finally(() => setLoadingPOIs(false));
  }, [searchCoords]);

  /* ================= RENDER POIs ================= */
  useEffect(() => {
    if (!mapRef.current || !clusterRef.current || areaDirty) {
      clusterRef.current?.clearLayers();
      return;
    }

    clusterRef.current.clearLayers();

    const center = L.latLng(searchCoords.lat, searchCoords.lon);

    allPOIs.forEach((p) => {
      if (p.tags?.amenity !== selectedCategory) return;

      const point = L.latLng(p.lat, p.lon);
      if (center.distanceTo(point) > radius) return;

      let marker = markerCache.current.get(p.id);
      if (!marker) {
        marker = L.marker([p.lat, p.lon], {
          icon: ICONS[selectedCategory],
        }).bindPopup(p.tags?.name || "Unnamed");
        markerCache.current.set(p.id, marker);
      }

      clusterRef.current.addLayer(marker);
    });
  }, [allPOIs, selectedCategory, radius, areaDirty]);


  /* ================= CATEGORY COUNTS ================= */
  const categoryCounts = useMemo(() => {
    const counts = { hospital: 0, clinic: 0, pharmacy: 0 };
    allPOIs.forEach((p) => {
      if (counts[p.tags?.amenity] !== undefined) counts[p.tags.amenity]++;
    });
    return counts;
  }, [allPOIs]);
  // ================ Nearest POI ================= //
  const findNearestPOI = (center, pois, category) => {
    let nearest = null;
    let minDist = Infinity;
    pois.forEach(p => {
      if (p.tags?.amenity !== category) return;
      const dist = Math.hypot(center.lat - p.lat, center.lon - p.lon);
      if (dist < minDist) {
        minDist = dist;
        nearest = p;
      }
    });
    return nearest;
  };

  // ====================================== showing shortest route ==========================
const handleShowRoute = async () => {
  if (!previewCoords || !allPOIs.length) return;

  // Find nearest POI
  const nearest = findNearestPOI(previewCoords, allPOIs, selectedCategory);
    if (!nearest) return;

    // Remove old route if exists
    if (routeRef.current) {
      mapRef.current.removeLayer(routeRef.current);
      routeRef.current = null;
    }

    try {
      const url = `https://router.project-osrm.org/route/v1/driving/${previewCoords.lon},${previewCoords.lat};${nearest.lon},${nearest.lat}?overview=full&geometries=geojson`;
      const res = await axios.get(url);

      const coords = res.data.routes[0].geometry.coordinates.map(c => [c[1], c[0]]); // [lat, lon]
      
      routeRef.current = L.polyline(coords, {
        color: "#2563eb",
        weight: 4,
        opacity: 0.8,
        dashArray: "8,4", // optional for style
      }).addTo(mapRef.current);

      // Zoom to fit the route
      mapRef.current.fitBounds(routeRef.current.getBounds(), { padding: [50, 50] });

    } catch (err) {
      console.error("Failed to fetch route:", err);
      alert("Unable to calculate route to nearest POI.");
    }
  };

  // ====================== category change ==========================
  const handleCategoryChange = (key) => {
    setSelectedCategory(key);

    // Remove old route if it exists
    if (routeRef.current) {
      mapRef.current.removeLayer(routeRef.current);
      routeRef.current = null;
    }
  };



  /* ================= UI ================= */
  return (
    <div style={{ height: "100vh", width: "100vw" }}>
      <Link className="Home_link" to="/">Home</Link>
      {/* <button className="Home_link" onClick={handleShowRoute} style={{ marginTop: "36px",outline:"none",border:"none" }}>
        Show route to nearest {selectedCategory}
      </button> */}
      {allPOIs.length > 0 && !areaDirty && (
        <button className="Home_link" onClick={handleShowRoute} style={{ marginTop: "36px",outline:"none",border:"none" }}>
          Show route to nearest {selectedCategory}
        </button>
      )}


      <div className="info-box">
        <strong>{selectedCategory}'s</strong>
        <br /><p style={{marginTop:"-20px",marginBottom:"0px"}}>near</p>
        {currentAddress || "Loading..."}
        <br />
        {!areaDirty && (
          <>
            Radius: {(radius / 1000).toFixed(1)} km
            <input
              type="range"
              min="1000"
              max="2500"
              step="500"
              value={radius}
              onChange={(e) => setRadius(+e.target.value)}
            />
          </>
        )}
        {loadingPOIs && (
          <div className="spinner-overlay">
            <div className="spinner"></div>
            <span style={{color:"white"}}>Loading POIs...</span>
          </div>
        )}

      </div>

      <div className="category-bar">
        {CATEGORY_OPTIONS.map((opt) => (
        <button
          key={opt.key}
          disabled={areaDirty}
          onClick={() => handleCategoryChange(opt.key)}
          className={[
            selectedCategory === opt.key ? "active" : "",
            opt.key
          ].join(" ").trim()}
        >
          <i className={`fa-solid ${opt.icon}`} /> {opt.label} ({categoryCounts[opt.key]})
        </button>
      ))}
        </div>

      {showHint && (
        <div className="Mappage_overlay">
          <button onClick={handleSearchThisArea}>Search this area</button>
          <button onClick={handleGoBack}>Go back</button>
        </div>
      )}

      <div id="map" style={{ height: "100%", width: "100%" }} />
    </div>
  );
}
