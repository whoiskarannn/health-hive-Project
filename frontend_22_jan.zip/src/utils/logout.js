const logout = (navigate) => {
  // Remove auth data
  localStorage.removeItem("token");
  localStorage.removeItem("user");

  // OPTIONAL: clear everything auth-related
  localStorage.clear();

  // Prevent going back to protected pages
  navigate("/login", { replace: true });
};

export default logout;
