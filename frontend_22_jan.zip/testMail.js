import dotenv from "dotenv";
import sendEmail from "./utils/sendEmail.js";

dotenv.config();

const runTest = async () => {
  try {
    await sendEmail({
      to: "as6569884@gmail.com", // <-- put YOUR email here
      subject: "HealthHive Test Email",
      html: "<h2>Nodemailer is working ✅</h2>",
    });

    console.log("✅ Test email sent successfully");
  } catch (err) {
    console.error("❌ Test email failed:", err.message);
  }
};

runTest();
