export const requireAdmin = (req, res, next) => {
  try {
    if (!req.user || req.user.role !== "admin") {
      return res.status(403).json({ message: "Admin access required" });
    }
    next();
  } catch (err) {
    console.error("Admin guard error:", err);
    res.status(500).json({ message: "Authorization failed" });
  }
};
