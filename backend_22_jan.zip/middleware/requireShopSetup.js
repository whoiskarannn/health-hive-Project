import User from "../models/User.js";

export default async function requireShopSetup(req, res, next) {
  try {
    const user = await User.findById(req.user.id).select("shop role");

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    if (user.role !== "pharmacist") {
      return res.status(403).json({ message: "Pharmacist only" });
    }

    if (!user.shop || user.shop.setupCompleted !== true) {
      return res.status(403).json({
        message: "Complete shop setup to access inventory",
        code: "SHOP_SETUP_REQUIRED",
      });
    }

    next();
  } catch (err) {
    console.error("Shop setup check failed:", err);
    return res.status(500).json({ message: "Server error" });
  }
}
