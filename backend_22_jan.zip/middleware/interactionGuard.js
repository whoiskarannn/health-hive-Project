import { INTERACTION_RULES } from "../utils/interactionRules.js";

export const interactionGuard = (action) => {
  return (req, res, next) => {
    const role = req.user?.role || "guest";

    const allowed = INTERACTION_RULES[role]?.[action];

    if (!allowed) {
      return res.status(403).json({
        message: "You are not allowed to perform this action"
      });
    }

    next();
  };
};

// ✅ What this does
// Blocks guests cleanly
// Keeps routes clean
// No duplication of checks