import mongoose from "mongoose";

const contentInteractionSchema = new mongoose.Schema(
  {
    contentId: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      index: true
    },

    contentType: {
      type: String,
      enum: ["post", "question", "answer"],
      required: true,
      index: true
    },

    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
      index: true
    },

    userRole: {
      type: String,
      required: true
    },

    action: {
      type: String,
      enum: ["like", "dislike", "share", "flag"],
      required: true
    },
    likedBy: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: "User"
    }],
        dislikedBy: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: "User"
    }]

  },
  { timestamps: true }
);

/**
 * Enforce ONE interaction per user per content per action
 * (likes, dislikes, flags toggle automatically)
 */
contentInteractionSchema.index(
  { contentId: 1, contentType: 1, userId: 1, action: 1 },
  { unique: true }
);

export default mongoose.model("ContentInteraction", contentInteractionSchema);

// What this guarantees
// No duplicate likes
// No duplicate dislikes
// No duplicate flags
// Shares allowed multiple times (we’ll handle that in logic)