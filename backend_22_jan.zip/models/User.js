import mongoose from "mongoose";

const shopSchema = new mongoose.Schema(
  {
    name: String,
    address: String,
    email: String,

    setupCompleted: {
      type: Boolean,
      default: false,
    },

    verificationStatus: {
      type: String,
      enum: ["unverified", "pending", "verified", "rejected"],
      default: "unverified",
    },

    documents: {
      pharmacyLicense: {
        url: String,
        uploadedAt: Date,
        status: {
          type: String,
          enum: ["pending", "approved", "rejected"],
          default: "pending",
        },
      },
      ownerIdProof: {
        url: String,
        uploadedAt: Date,
        status: {
          type: String,
          enum: ["pending", "approved", "rejected"],
          default: "pending",
        },
      },
      gstCertificate: {
        url: String,
        uploadedAt: Date,
        status: {
          type: String,
          enum: ["pending", "approved", "rejected"],
          default: "pending",
        },
      },
    },
  },
  { _id: false }
);

const UserSchema = new mongoose.Schema(
  {
    name: { type: String, default: "Anonymous", trim: true },
    email: { type: String, unique: true, sparse: true, lowercase: true },
    password: String,

    role: {
      type: String,
      enum: ["guest", "user", "student", "doctor", "pharmacist"],
      required: true,
    },

    avatar: { type: String, default: "/default-avatar.png" },
    bio: { type: String, default: "" },

    isEmailVerified: { type: Boolean, default: false },
    isRoleVerified: { type: Boolean, default: false },

    emailVerifyToken: String,
    emailVerifyExpires: Date,

    guestId: String,

    shop: {
      type: shopSchema,
      default: undefined,
    },
  },
  {
    timestamps: true,
    toJSON: {
      transform: (_, ret) => {
        ret.id = ret._id;
        delete ret._id;
        delete ret.__v;
        delete ret.password;
      },
    },
  }
);

export default mongoose.model("User", UserSchema);
