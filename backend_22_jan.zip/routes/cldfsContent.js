import express from "express";
import mongoose from "mongoose";
import ContentInteraction from "../models/ContentInteraction.js";
import { verifyUser } from "./authroutes.js";
import { interactionGuard } from "../middleware/interactionGuard.js";

const router = express.Router();

/**
 * INTERACT WITH CONTENT
 * like | dislike | share | flag
 */
router.post(
  "/interact",
  verifyUser, // enable authentication
  async (req, res) => {
    try {
      let { contentId, contentType, action } = req.body;

      // ---------- Normalize ----------
      contentType = contentType.toLowerCase();
      if (contentType.endsWith("s")) contentType = contentType.slice(0, -1); // questions -> question
      action = action.toLowerCase();

      // ---------- Validate ----------
      if (!contentId || !contentType || !action) {
        return res.status(400).json({ message: "Missing required fields" });
      }

      if (!["post", "question", "answer"].includes(contentType)) {
        return res.status(400).json({ message: "Invalid content type" });
      }

      if (!["like", "dislike", "share", "flag"].includes(action)) {
        return res.status(400).json({ message: "Invalid action" });
      }

      const userId = req.user.id;
      const userRole = req.user.role;

      /** ROLE GUARD */
      const guard = interactionGuard(action);
      guard(req, res, async () => {

        // ---------- LIKE / DISLIKE TOGGLE ----------
        if (action === "like" || action === "dislike") {
            const opposite = action === "like" ? "dislike" : "like";

            // Remove opposite if exists
            await ContentInteraction.deleteOne({
                contentId,
                contentType,
                userId,
                action: opposite
            });

            // Toggle current interaction atomically
            const existing = await ContentInteraction.findOne({
                contentId,
                contentType,
                userId,
                action
            });

            if (existing) {
                await existing.deleteOne();
                return res.json({ message: `${action} removed` });
            } else {
                await ContentInteraction.create({
                contentId,
                contentType,
                userId,
                userRole,
                action
                });
                return res.json({ message: `${action} added` });
            }
            }

        // ---------- SHARE / FLAG (idempotent) ----------
        if (action === "share" || action === "flag") {
          const existing = await ContentInteraction.findOne({
            contentId,
            contentType,
            userId,
            action
          });

          if (existing) {
            return res.json({ message: `Already ${action}ed` });
          }

          await ContentInteraction.create({
            contentId,
            contentType,
            userId,
            userRole,
            action
          });

          return res.json({ message: `${action}ed successfully` });
        }
      });

    } catch (err) {
      console.error("Interaction error:", err);
      res.status(500).json({ message: "Interaction failed" });
    }
  }
);


/**
 * GET CONTENT STATS
 */
router.get("/stats/:contentType/:contentId", async (req, res) => {
  try {
    let { contentType, contentId } = req.params;

    contentType = contentType.toLowerCase();
    if (contentType.endsWith("s")) contentType = contentType.slice(0, -1);

    const stats = await ContentInteraction.aggregate([
      {
        $match: {
          contentId: new mongoose.Types.ObjectId(contentId),
          contentType
        }
      },
      {
        $group: {
          _id: "$action",
          count: { $sum: 1 }
        }
      }
    ]);

    const response = {
      likes: 0,
      dislikes: 0,
      shares: 0,
      flags: 0
    };

    stats.forEach(s => {
      response[s._id + "s"] = s.count;
    });

    res.json(response);
  } catch (err) {
    console.error("Stats fetch error:", err);
    res.status(500).json({ message: "Failed to fetch stats" });
  }
});

export default router;
