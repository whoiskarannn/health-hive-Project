import express from "express";
import {
  getAllPharmacistShops,
  approvePharmacistShop,
  rejectPharmacistShop,
} from "../controllers/adminController.js";
import { verifyAdmin } from "../middleware/verifyAdmin.js";
import User from "../models/User.js";

const router = express.Router();

// GET all pharmacists
router.get("/pharmacists", verifyAdmin, getAllPharmacistShops);

// Get single pharmacist by ID
router.get("/pharmacist/:id", verifyAdmin, async (req, res) => {
  try {
    const pharmacist = await User.findOne({
      _id: req.params.id,
      role: "pharmacist",
    });

    if (!pharmacist) {
      return res.status(404).json({ message: "Pharmacist not found" });
    }

    res.json({ pharmacist });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error" });
  }
});


// PATCH single document approval/rejection
router.patch("/pharmacist/:id/document", verifyAdmin, async (req, res) => {
  const { documentType, status } = req.body;

  if (!documentType || !status) {
    return res.status(400).json({ message: "documentType and status are required" });
  }

  try {
    const pharmacist = await User.findOne({
      _id: req.params.id,
      role: "pharmacist",
    });

    if (!pharmacist) {
      return res.status(404).json({ message: "Pharmacist not found" });
    }

    if (!pharmacist.shop?.documents[documentType]) {
      return res.status(404).json({ message: "Document not found" });
    }

    pharmacist.shop.documents[documentType].status = status;
    await pharmacist.save();

    res.json({
      message: `Document ${documentType} ${status}`,
      pharmacist,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error" });
  }
});

// PATCH approve pharmacist
router.patch("/pharmacists/:id/approve", verifyAdmin, approvePharmacistShop);

// PATCH reject pharmacist
router.patch("/pharmacists/:id/reject", verifyAdmin, rejectPharmacistShop);

export default router;
