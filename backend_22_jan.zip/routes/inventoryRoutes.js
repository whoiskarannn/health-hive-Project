import express from "express";
import multer from "multer";
import { verifyUser } from "../routes/authroutes.js";
import {
  getMyInventory,
  upsertInventory,
  uploadInventoryCSV,
  getInventorySummary
} from "../controllers/inventoryController.js";
import requireShopSetup from "../middleware/requireShopSetup.js";


const router = express.Router();
const upload = multer({ storage: multer.memoryStorage() });

/**
 * Auth check
 */
const requireAuth = (req, res, next) => {
  if (!req.user) {
    return res.status(401).json({ message: "Not authenticated" });
  }
  next();
};

/**
 * Pharmacist-only check
 */
const requirePharmacist = (req, res, next) => {
  if (req.user.role !== "pharmacist") {
    return res.status(403).json({ message: "Pharmacist only" });
  }
  next();
};

/**
 * GET my inventory
 */
router.get(
  "/me",
  verifyUser,
  requireAuth,
  requirePharmacist,
  requireShopSetup,
  getMyInventory,
  getInventorySummary
);

/**
 * GET inventory summary (dashboard use)
 */
router.get(
  "/summary",
  verifyUser,
  requireAuth,
  requirePharmacist,
  requireShopSetup,
  getInventorySummary
);


router.post(
  "/me",
  verifyUser,
  requireAuth,
  requirePharmacist,
  requireShopSetup,
  upsertInventory,
  getInventorySummary
);

router.post(
  "/upload-csv",
  verifyUser,
  requireAuth,
  requirePharmacist,
  requireShopSetup,
  upload.single("file"),
  uploadInventoryCSV,
  getInventorySummary
);

export default router;


