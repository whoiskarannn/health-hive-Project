// routes/medicineRoutes.js
import express from "express";
import { verifyUser } from "./authRoutes.js"; // adjust path if needed
import requirePharmacist from "../middleware/requirePharmacist.js";
import {
  addMedicine,
  getMedicines,
} from "../controllers/medicineController.js";

const router = express.Router();

router.use(verifyUser, requirePharmacist);

router.post("/", addMedicine);
router.get("/", getMedicines);

export default router;
