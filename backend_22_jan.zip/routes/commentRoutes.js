import express from "express";
import Comment from "../models/Comment.js";
import mongoose from "mongoose";
import { verifyUser } from "./authroutes.js";

const router = express.Router();

router.post("/", verifyUser, async (req, res) => {
  const { text, parentCommentId, contentType, contentId } = req.body;

  if (!contentType || !contentId) {
    return res.status(400).json({ message: "contentType and contentId are required" });
  }

  if (!text || !text.trim()) {
    return res.status(400).json({ message: "Comment cannot be empty" });
  }

  const comment = await Comment.create({
    contentType,
    contentId,
    userId: new mongoose.Types.ObjectId(req.user.id),
    text,
    parentCommentId: parentCommentId || null,
  });


  res.status(201).json(comment);
});


router.get("/:contentType/:contentId", async (req, res) => {
  const { contentType, contentId } = req.params;
  const comments = await Comment.find({
    contentType,
    contentId,
    isDeleted: false,
  })
    .populate("userId", "name avatar")
    .sort({ createdAt: 1 });
  res.json(comments);
});


router.delete("/:id", verifyUser, async (req, res) => {
  try {
    const comment = await Comment.findById(req.params.id);

    if (!comment) {
      return res.status(404).json({ message: "Comment not found" });
    }

    // 🔒 OWNER CHECK
    if (comment.userId.toString() !== req.user.id) {
      return res.status(403).json({ message: "Not authorized to delete this comment" });
    }

    await comment.deleteOne();

    res.json({ message: "Comment deleted successfully" });
  } catch (error) {
    console.error("Delete comment error:", error);
    res.status(500).json({ message: "Failed to delete comment" });
  }
});


// edit comment
router.put("/:commentId", verifyUser, async (req, res) => {
  const { text } = req.body;
  const comment = await Comment.findById(req.params.commentId);

  if (!comment) return res.status(404).json({ message: "Not found" });

  if (comment.userId.toString() !== req.user.id) {
  return res.status(403).json({ message: "Not authorized" });
}
  comment.text = text;
  await comment.save();

  res.json(comment);
});

export default router;
