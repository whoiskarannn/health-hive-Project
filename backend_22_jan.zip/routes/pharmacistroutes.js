import express from "express";
import User from "../models/User.js";
import { verifyUser } from "./authroutes.js";
import { upload } from "../middleware/upload.js";
import multer from "multer";

const router = express.Router();

/** Auth & Pharmacist checks */
const requireAuth = (req, res, next) => {
  if (!req.user) {
    return res.status(401).json({ message: "Not authenticated" });
  }
  next();
};

const requirePharmacist = (req, res, next) => {
  if (req.user.role !== "pharmacist") {
    return res.status(403).json({ message: "Pharmacist only" });
  }
  next();
};

/**
 * Upload shop verification documents
 */
router.post(
  "/upload-documents",
  verifyUser,
  requireAuth,
  requirePharmacist,
  upload.fields([
    { name: "pharmacyLicense", maxCount: 1 },
    { name: "ownerIdProof", maxCount: 1 },
    { name: "gstCertificate", maxCount: 1 },
  ]),
  async (req, res) => {
    try {
      const user = await User.findById(req.user.id);

      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      if (!req.files || Object.keys(req.files).length === 0) {
        return res.status(400).json({ message: "No documents uploaded" });
      }

      if (!user.shop) user.shop = {};
      if (!user.shop.documents) user.shop.documents = {};

      Object.entries(req.files).forEach(([field, fileArr]) => {
        const file = fileArr[0];

        user.shop.documents[field] = {
          url: `/uploads/${file.filename}`,
          uploadedAt: new Date(),
          status: "pending",
        };
      });

      user.shop.verificationStatus = "pending";

      await user.save();

      return res.json({
        message: "Documents uploaded successfully",
        documents: user.shop.documents,
      });
    } catch (err) {
      console.error("Upload error:", err);
      return res.status(500).json({ message: "Upload failed" });
    }
  }
);

/**
 * Fetch current pharmacist shop
 */
router.get(
  "/shop",
  verifyUser,
  requireAuth,
  requirePharmacist,
  async (req, res) => {
    try {
      const user = await User.findById(req.user.id).select("shop");

      if (!user || !user.shop) {
        return res.json({ shop: null });
      }

      return res.json({ shop: user.shop });
    } catch (err) {
      console.error("Fetch shop error:", err);
      return res.status(500).json({ message: "Failed to fetch shop" });
    }
  }
);
/**
 * Update pharmacist shop details
 */
router.patch(
  "/shop",
  verifyUser,
  requireAuth,
  requirePharmacist,
  async (req, res) => {
    try {
      const { name, address, email } = req.body;

      if (!name || !address || !email) {
        return res.status(400).json({ message: "All fields are required" });
      }

      const user = await User.findById(req.user.id);

      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      if (!user.shop) {
        user.shop = {};
      }

      user.shop.name = name;
      user.shop.address = address;
      user.shop.email = email;

      await user.save();

      return res.json({
        message: "Shop updated successfully",
        user: {
          id: user._id,
          role: user.role,
          shop: user.shop,
        },
      });
    } catch (err) {
      console.error("Update shop error:", err);
      return res.status(500).json({ message: "Failed to update shop" });
    }
  }
);

/**
 * Multer error handler (important)
 */
router.use((err, req, res, next) => {
  if (err instanceof multer.MulterError) {
    return res.status(400).json({ message: err.message });
  }

  if (err.message === "Invalid file type") {
    return res.status(400).json({ message: "Invalid file type" });
  }

  next(err);
});

export default router;
