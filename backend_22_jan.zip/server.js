import express from "express";
import mongoose from "mongoose";
import cors from "cors";
import dotenv from "dotenv";
import cookieParser from "cookie-parser";
import multer from "multer";
import path from "path";
// Routes
import authRoute from "./routes/authroutes.js";
import SpacesRoute from "./routes/Spaceroutes.js";
import questionsRoute from "./routes/questionroutes.js";
import PostsRoute from "./routes/postRoutes.js";
import feedRoute from "./routes/feedroutes.js";
import searchRoute from "./routes/searchroutes.js";
import inventoryRoutes from "./routes/inventoryRoutes.js";
import pharmacistRoutes from "./routes/pharmacistroutes.js";
import adminRoutes from "./routes/adminRoutes.js";
import adminAuthRoutes from "./routes/adminAuthRoutes.js";
// interaction Routes
import cldfsContentRoutes from "./routes/cldfsContent.js"
import commentRoutes from "./routes/commentRoutes.js";



dotenv.config();

const app = express();

/* =========================
   ✅ CORS (SAFE + CORRECT)
   ========================= */
app.use(
  cors({
    origin: "http://localhost:5173",
    credentials: true,
    methods: ["GET", "POST", "PUT", "PATCH", "DELETE"],
    allowedHeaders: ["Content-Type", "Authorization"],
  })
);

/* =========================
   ✅ Core middleware
   ========================= */
app.use(cookieParser());
app.use(express.json());

/* =========================
   ✅ Routes
   ========================= */
app.use("/api/auth", authRoute);
app.use("/api/spaces", SpacesRoute);
app.use("/api/questions", questionsRoute);
app.use("/api/posts", PostsRoute);
app.use("/api/feed", feedRoute);
app.use("/api/search", searchRoute);
app.use("/api/inventory", inventoryRoutes);
app.use("/api/pharmacist", pharmacistRoutes);
// app.use("/api/shop/me", inventoryRoutes);
app.use("/uploads", express.static(path.join(process.cwd(), "uploads")));
app.use("/api/admin", adminRoutes);
app.use("/api/admin/auth", adminAuthRoutes);

// interactions apis =================================
app.use("/api/content", cldfsContentRoutes);
app.use("/api/comments", commentRoutes);

/* =========================
   ✅ Global error handler
   ========================= */
app.use((err, req, res, next) => {
  if (err instanceof multer.MulterError) {
    return res.status(400).json({ message: err.message });
  }
  if (err) {
    console.error("Server error:", err);
    return res.status(500).json({ message: err.message });
  }
  next();
});

/* =========================
   ✅ MongoDB + Server
   ========================= */
mongoose
  .connect(process.env.MONGO_URI)
  .then(() => {
    console.log("MongoDB Atlas connected");
    app.listen(process.env.PORT, () => {
      console.log(`Server running on port ${process.env.PORT}`);
    });
  })
  .catch((err) => console.error("MongoDB error:", err));

  
  
// This is the bakend connection environment 
// If i ever want to connect to myatlas db collecyions jus tuse this folder and
// change the collection name from "spaces" tp => "<new collection name>"