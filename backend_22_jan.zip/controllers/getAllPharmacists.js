import User from "../models/User.js";

export const getAllPharmacists = async (req, res) => {
  try {
    const { status } = req.query;

    let filter = { role: "pharmacist" };
    if (status) filter["shop.verificationStatus"] = status;

    const pharmacists = await User.find(filter).select(
      "_id name email shop"
    );

    res.json({ pharmacists });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Failed to fetch pharmacists" });
  }
};
