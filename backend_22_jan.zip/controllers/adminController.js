import User from "../models/User.js";

/**
 * GET all pharmacist shops
 * Optional filter: ?status=pending|verified|rejected|unverified
 */
export const getAllPharmacistShops = async (req, res) => {
  try {
    const { status } = req.query;

    const query = {
      role: "pharmacist",
      shop: { $exists: true },
    };

    if (status) {
      query["shop.verificationStatus"] = status;
    }

    // ✅ Include _id explicitly
    const pharmacists = await User.find(query).select("_id name email shop createdAt");

    // Optional: map _id to id for frontend convenience
    const formatted = pharmacists.map(p => ({ ...p.toObject(), id: p._id }));

    return res.json({
      count: formatted.length,
      pharmacists: formatted,
    });
  } catch (error) {
    console.error("Fetch pharmacists error:", error);
    return res.status(500).json({
      message: "Failed to fetch pharmacist shops",
    });
  }
};


/**
 * APPROVE pharmacist shop
 */
/**
 * APPROVE pharmacist shop
 */
export const approvePharmacistShop = async (req, res) => {
  try {
    const { id } = req.params;

    if (!id) return res.status(400).json({ message: "Invalid pharmacist ID" });

    const user = await User.findOne({ _id: id, role: "pharmacist", shop: { $exists: true } });

    if (!user) return res.status(404).json({ message: "Pharmacist not found" });

    // ✅ Approve both shop and role
    user.shop.verificationStatus = "verified";
    user.isShopVerified = true;      // new explicit field
    user.isRoleVerified = true;

    await user.save();

    return res.json({
      message: "Pharmacist shop approved",
      pharmacistId: user._id,
      status: user.shop.verificationStatus,
    });
  } catch (error) {
    console.error("Approve shop error:", error);
    return res.status(500).json({ message: "Failed to approve shop" });
  }
};

/**
 * REJECT pharmacist shop
 */
export const rejectPharmacistShop = async (req, res) => {
  try {
    const { id } = req.params;

    if (!id) return res.status(400).json({ message: "Invalid pharmacist ID" });

    const user = await User.findOne({ _id: id, role: "pharmacist", shop: { $exists: true } });

    if (!user) return res.status(404).json({ message: "Pharmacist not found" });

    // ✅ Reject both shop and role
    user.shop.verificationStatus = "rejected";
    user.isShopVerified = false;     // new explicit field
    user.isRoleVerified = false;

    await user.save();

    return res.json({
      message: "Pharmacist shop rejected",
      pharmacistId: user._id,
      status: user.shop.verificationStatus,
    });
  } catch (error) {
    console.error("Reject shop error:", error);
    return res.status(500).json({ message: "Failed to reject shop" });
  }
};
