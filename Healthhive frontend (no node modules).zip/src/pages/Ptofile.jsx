export default function Profile() {
  const user = JSON.parse(localStorage.getItem("user"));

  if (!user) {
    return <p>Please log in to view your profile.</p>;
  }

  return (
    <div className="profile-page">
      <img
        src={user.avatar || "/default-avatar.png"}
        alt="avatar"
        width="80"
      />
      <h2>{user.name}</h2>
      <p>Email: {user.email || "Not available"}</p>
    </div>
  );
}
