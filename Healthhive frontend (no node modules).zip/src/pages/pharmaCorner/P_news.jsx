import "./P_news.css";

const P_news = () => {
  return (
    <div className="insights-wrapper">
      {/* Latest News */}
      <section className="insight-card">
        <h3>Latest News</h3>
        <ul>
          <li>New medicine pricing policy announced</li>
          <li>Cold & flu medicines trending this season</li>
          <li>Regulatory update on antibiotics</li>
        </ul>
      </section>

      {/* Trending Medicines */}
      <section className="insight-card">
        <h3>Trending Medicines</h3>
        <ul>
          <li>Paracetamol</li>
          <li>Azithromycin</li>
          <li>Vitamin D3</li>
        </ul>
      </section>

      {/* Most Searched */}
      <section className="insight-card">
        <h3>Most Searched</h3>
        <ol>
          <li>Insulin</li>
          <li>BP Medicines</li>
          <li>Antibiotics</li>
        </ol>
      </section>
    </div>
  );
};

export default P_news;
