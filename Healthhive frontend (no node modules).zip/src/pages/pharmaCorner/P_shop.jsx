import "./P_shop.css";
import { Link } from "react-router-dom";

const ShopOverviewPage = () => {
  return (
    <div className="shop-wrapper">
      {/* My Shop */}
      <section className="shop-card">
        <h3>My Shop</h3>
        <p>Status: Active</p>
        <p>Total Medicines: 142</p>
        <p>Low Stock Alerts: 7</p>
        <Link to="/p-inventory" >Go to inventory</Link>
      </section>

    </div>
  );
};

export default ShopOverviewPage;
