import Navbar from "../../components/Navbar";
import Sidebar from "../../components/Sidebar";
import "./P_dashboard.css";
import P_news from "./P_news";
import P_shop from "./P_shop";

const p_dashboard = () => {
  return (
    <>
    <Navbar />
    {/* <Sidebar /> */}
       <div className="home-dashboard">
         <h2>Pharmacist Dashboard</h2>
      <div className="inside-section">
        <P_shop /><br />
        <P_news /><br />
      </div>
      
       
         </div>
    </>
  );
};

export default p_dashboard;
