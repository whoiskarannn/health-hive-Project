import Sidebar from "../components/Sidebar";
import Searchbar from "../components/Searchbar";
import Navbar from "../components/Navbar";
import QuestionsList from "../QA/QuestionsList"; // not needed for now

import { useState } from "react";
import AskPost from "../QA/AskPost";

export default function Home() {
  const [showAskPost, setShowAskPost] = useState(false);
  const [activeTab, setActiveTab] = useState("ask");

  return (


  <div>
      <Navbar />
        <div style={{ display: "flex" , marginTop: "16px"}}>
           <Sidebar />
     
      <main style={{ flex: 1, maxWidth: "800px", margin: "0 auto" }}>
           
        <Searchbar
          onAsk={() => {
            setActiveTab("ask");
            setShowAskPost(true);
          }}
          onPost={() => {
            setActiveTab("post");
            setShowAskPost(true);
          }}
      />

        <AskPost
          isOpen={showAskPost}
          activeTab={activeTab}
          onClose={() => setShowAskPost(false)}
        />
        <div>
          <QuestionsList mode="enter mode here"/> {/* this mode is responsible to show feed data in homepage can be changed to "questions" , "posts"*/}
        
        </div>
      </main>
    </div>
  </div>
    
  );
}

    