
import axios from "axios";

const BASE_URL = "http://localhost:5000/api/auth";

// register user
export const registerUser = (data) => {
  return axios.post(`${BASE_URL}/register`, {
    name: data.name,
    email: data.email,
    password: data.password,
    role: data.role,
  });
};

// login user
export const loginUser = (data) => {
  return axios.post(`${BASE_URL}/login`, {
    email: data.email,
    password: data.password,
  });
};

//  verify email
export const verifyEmail = async (token) => {
  const res = await fetch(`${BASE_URL}/verify-email?token=${token}`);
  return res.json();
};
