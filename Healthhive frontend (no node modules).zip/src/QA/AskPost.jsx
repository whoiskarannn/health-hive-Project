import { useState, useEffect } from "react";
import "./AskPost.css";
import { createQuestion, createPost } from "../api/QAapi.js";
import AuthRequiredModal from  "../components/AuthRequiredModal.jsx"

function AskPost({ isOpen, activeTab = "ask", onClose }) {
  const user = JSON.parse(localStorage.getItem("user"));
  const [tab, setTab] = useState(activeTab);

  const [showAuthPopup, setShowAuthPopup] = useState(false);
  const [isDirty, setIsDirty] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);

  // 🔹 NEW: single form state
  const [form, setForm] = useState({
    title: "",
    content: ""
  });

  // 🔹 handleChange updated
  const handleChange = (e) => {
    const { name, value } = e.target;
    setIsDirty(true);
    setForm(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleCloseAttempt = () => {
    if (!isDirty) {
      onClose();
      return;
    }
    setShowConfirm(true); // show custom modal
  };

  // prevents pages with something written from closing without consent
  useEffect(() => {
    setTab(activeTab);
  }, [activeTab]);

  if (!isOpen) return null;

  if (!user) {
    return (
      <AuthRequiredModal
        isOpen={true}
        onClose={onClose}
      />
    );
  }

  // 🔹 handleSubmit reads from form
  const handleSubmit = async () => {
    try {
      if (tab === "ask" && user) {
        await createQuestion({ title: form.title, content: form.content });
        console.log("Question added");
      }

      if (tab === "post" && user) {
        await createPost({ title: form.title, content: form.content });
        console.log("Post created");
      }

      setIsDirty(false);
      onClose();
    } catch (error) {
      console.error("Submission failed", error);
    }
  };

  // 🔹 resetForm updates form state
  const resetForm = () => {
    setForm({ title: "", content: "" });
    setIsDirty(false);
  };

  return (
    <>
      <div className="askpost-overlay">
        <div className="askpost-modal">
          {/* Header */}
          <div className="askpost-header">
            <div className="askpost-tabs">
              <button 
                className={tab === "ask" ? "active" : ""}
                onClick={() => setTab("ask")}
              >
                Ask
              </button>
              <button 
                className={tab === "post" ? "active" : ""}
                onClick={() => setTab("post")}
              >
                Post
              </button>
            </div>

            <button className="close-btn" onClick={handleCloseAttempt}>
              ✕
            </button>
          </div>

          {/* Body */}
          <div className="askpost-body">
            {tab === "ask" && (
              <>
                <input
                  type="text"
                  name="title"
                  required
                  placeholder="Start your question with What, Why, How, etc."
                  value={form.title}
                  onChange={handleChange}
                />

                <textarea
                  name="content"
                  required
                  placeholder="Add more details (optional)"
                  value={form.content}
                  onChange={handleChange}
                />

                <div className="meta-row">
                  <span>📌 Medical</span>
                  <span>🌐 Public</span>
                </div>
              </>
            )}

            {tab === "post" && (
              <>
                <input
                  type="text"
                  name="title"
                  required
                  placeholder="Write something"
                  value={form.title}
                  onChange={handleChange}
                />
                <textarea
                  name="content"
                  required
                  placeholder="Say something..."
                  value={form.content}
                  onChange={handleChange}
                />

                <div className="meta-row">
                  <span>🌐 Public</span>
                </div>
              </>
            )}
          </div>

          {/* Footer */}
          <div className="askpost-footer">
            <button className="cancel-btn" onClick={handleCloseAttempt}>
              Cancel
            </button>

            <button
              type="button"
              className="askpost-submit-btn"
              onClick={() => {
                handleSubmit();
                 resetForm();
              }}            
            >
              {tab === "ask" ? "Add Question" : "Post"}
            </button>

            {showConfirm && (
              <div className="discard-overlay">
                <div className="discard-modal" role="dialog" aria-modal="true">
                  <div className="discard-header">
                    <span className="discard-icon">⚠️</span>
                    <h3>Discard your changes?</h3>
                  </div>

                  <p className="discard-text">
                    You have unsaved content. If you discard, your draft will be permanently lost.
                  </p>

                  <div className="discard-actions">
                    <button
                      className="btn-secondary"
                      onClick={() => setShowConfirm(false)}
                    >
                      Continue editing
                    </button>

                    <button
                      className="btn-danger"
                      onClick={() => {
                        resetForm();
                        setShowConfirm(false);
                        onClose();
                      }}
                    >
                      Discard
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      <AuthRequiredModal
        isOpen={showAuthPopup}
        onClose={() => setShowAuthPopup(false)}
      />
    </>
  );
}

export default AskPost;
