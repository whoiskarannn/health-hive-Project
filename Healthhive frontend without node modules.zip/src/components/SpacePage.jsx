import React from "react";
import { useParams } from "react-router-dom";

const SpacePage = () => {
  const { title } = useParams();

  return (
    <div style={styles.container}>
      <h1 style={styles.header}>{decodeURIComponent(title)}</h1>
      <p style={styles.text}>
        Welcome to <strong>{decodeURIComponent(title)}</strong>. This is a dynamically rendered space page.
      </p>
      <p style={styles.text}>You can add posts, members, or other content here based on the space.</p>
    </div>
  );
};

const styles = {
  container: {
    padding: "2rem",
    color: "#fff",
    backgroundColor: "#121212",
    minHeight: "100vh"
  },
  header: {
    fontSize: "2rem",
    marginBottom: "1rem"
  },
  text: {
    fontSize: "1rem",
    lineHeight: "1.6"
  }
};

export default SpacePage;
