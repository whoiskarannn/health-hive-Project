export function logout(navigate) {
  localStorage.removeItem("user");
  navigate("/login");
}
