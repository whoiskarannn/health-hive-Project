import { useEffect, useState } from "react";
import pharmacyinventoryapi from "../api/pharmacyinventoryapi";
import "./css/PharmacistDashboard.css"

export default function PharmacistDashboard() {
  const user = JSON.parse(localStorage.getItem("user"));

  const [items, setItems] = useState([]);
  const [lastUpdated, setLastUpdated] = useState(null);
  const [loading, setLoading] = useState(true);

  const fetchInventory = async () => {
    try {
      const { data } = await pharmacyinventoryapi.get("/inventory/me");
      setItems(data.items || []);
      setLastUpdated(data.lastUpdatedAt || null);
    } catch (err) {
      console.error("Failed to fetch inventory", err);
    } finally {
      setLoading(false);
    }
  };

  if (!user || user.role?.toLowerCase() !== "pharmacist") {
    return (
      <div className="page">
        <h3>Access Restricted</h3>
        <p>This dashboard is available only to verified pharmacists.</p>
      </div>
    );
  }

  useEffect(() => {
    fetchInventory();
  }, []);

  const updateInventory = async () => {
    try {
      await pharmacyinventoryapi.post("/inventory/me", { items });
      alert("Inventory updated");
      fetchInventory();
    } catch (err) {
      alert("Failed to update inventory");
    }
  };

  const addItem = () => {
    setItems([
      ...items,
      { medicineName: "", brand: "", quantity: 0, price: "" },
    ]);
  };

  const updateItem = (index, field, value) => {
    const copy = [...items];
    copy[index][field] = value;
    setItems(copy);
  };

  const uploadCSV = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const formData = new FormData();
    formData.append("file", file);

    try {
      await pharmacyinventoryapi.post("/inventory/upload-csv", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      alert("Inventory uploaded");
      fetchInventory();
    } catch (err) {
      alert("CSV upload failed");
    }
  };

  if (loading) return <p>Loading inventory...</p>;

  return (
    <div className="page">
      {/* ================= Header ================= */}
      <div className="dashboard-header">
        <h2>
          Welcome{user?.name ? `, ${user.name}` : ""}
          <span className="role-badge">Pharmacist</span>
        </h2>

        {lastUpdated && (
          <p className="updated-at">
            Last updated: {new Date(lastUpdated).toLocaleString()}
          </p>
        )}
      </div>

      {/* ================= CSV Upload ================= */}
      <div className="csv-upload">
        <label>
          Upload CSV
          <input type="file" accept=".csv" onChange={uploadCSV} hidden />
        </label>
      </div>

      {/* ================= Inventory List ================= */}
      <h3>Inventory</h3>

      {items.length === 0 && (
        <p className="muted-text">No medicines added yet.</p>
      )}

      {items.map((item, i) => (
        <div key={i} className="inventory-row">
          <input
            placeholder="Medicine name"
            value={item.medicineName}
            onChange={(e) =>
              updateItem(i, "medicineName", e.target.value)
            }
          />
          <input
            placeholder="Brand"
            value={item.brand || ""}
            onChange={(e) => updateItem(i, "brand", e.target.value)}
          />
          <input
            type="number"
            placeholder="Qty"
            value={item.quantity}
            onChange={(e) =>
              updateItem(i, "quantity", e.target.value)
            }
          />
          <input
            type="number"
            placeholder="Price"
            value={item.price || ""}
            onChange={(e) => updateItem(i, "price", e.target.value)}
          />
        </div>
      ))}

      {/* ================= Actions ================= */}
      <div className="inventory-actions">
        <button onClick={addItem}>+ Add Medicine</button>
        <button onClick={updateInventory}>Save Inventory</button>
      </div>
    </div>
  );
}
