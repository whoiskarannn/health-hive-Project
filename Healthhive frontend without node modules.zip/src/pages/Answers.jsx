import React from 'react'
import QuestionsList from '../QA/QuestionsList'
import Navbar from '../components/Navbar'
import "../QA/QuestionsList.css"


export default function Answers({onAsk, onPost}) {
  return (
    <>
    <Navbar />
    <div style={{display:"flex", flexDirection:"column", alignItems:"center"}}>       
    
        <h2 className="qa-title">
            Questions for you 
        </h2>
        <QuestionsList  mode="questions" />
    </div>
    </>
  )
}


