import { useState } from "react";
import { Link } from "react-router-dom";
import "./css/NavbarProfile.css";
import { useNavigate } from "react-router-dom";
import { logout } from "../utils/logout.js";


export default function NavbarProfile({ user }) {
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();

  if (!user) return null;

  return (
    <div className="profile-wrapper">
      <button className="profile-btn" onClick={() => setOpen(!open)}>
      {/* we are using this instead of img cause of fontawesom icon */}
        {user?.avatar ? (
        <img
            title="Profile"
            src={user.avatar}
            alt={`${user.name}'s profile `}
            className="profile-avatar"
        />
        ) : (
        <div className="profile-avatar fallback">
            <i class="fa-solid fa-user"></i>
        </div>
        )}

        {/* <span className="profile-name">{user.name}</span> */}
      </button>

      {open && (
        <div className="profile-dropdown">
          <Link to="/subscriptions">Subscriptions</Link>
          <Link to="/dashboard">Dashboard</Link>
          <Link to="/comments">Comments</Link>
          <Link to="/following">Following</Link>
          <hr />
          <Link to="/profile">My Profile</Link>

          <button
            className="logout-btn"
            onClick={() => logout(navigate)}
          >
            Logout
          </button>
        </div>
      )}
    </div>
  );
}
