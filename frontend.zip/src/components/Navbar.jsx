import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import FilterPopup from "./FilterPopup"; // Ensure path is correct
import "./css/Navbar.css";
import NavbarProfile from "./NavbarProfile";

export default function Navbar() {
  const navigate = useNavigate();
  const [showPopup, setShowPopup] = useState(false);

  // ✅ Read user from localStorage and update on mount
  const [user, setUser] = useState(null);

  useEffect(() => {
    const storedUser = localStorage.getItem("user");
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
  }, []);

  // 🔍 Search Box submit handler
  const handleFilterSubmit = ({ category, location }) => {
    const encodedPlace = encodeURIComponent(location);
    const encodedCategory = encodeURIComponent(category);
    navigate(`/mappage?place=${encodedPlace}&category=${encodedCategory}`);
  };

  return (
    <>
      <div className="navbar">
        <div className="navbar-section">
          {/* Profile dropdown component */}
       

          {/* Nav Buttons */}
          <Link to="/" className="Nav-btn">
            <i title="Home" alt="Home" className="fas fa-home nav-icon"></i>
          </Link>
          <button className="Nav-btn">
            <i title="News" alt="news" className="fas fa-newspaper nav-icon"></i>
          </button>
          <button className="Nav-btn">
            <i title="Post" alt="Post" className="fas fa-pen nav-icon"></i>
          </button>
          <button className="Nav-btn">
            <i title="Spaces" alt="spaces" className="fas fa-users nav-icon"></i>
          </button>
          <button className="Nav-btn">
            <i title="Notifications" alt="notifications" className="fas fa-bell nav-icon"></i>
          </button>

          {/* 🔍 Search Box */}
          <div className="search-box" onClick={() => setShowPopup(true)}>
            <i className="fas fa-search"></i>
            <input
              type="text"
              placeholder="Find medicine, hospitals and more"
              readOnly
            />
          </div>

          {/* Avatar (fallback if user is not set) */}
             <NavbarProfile user={user} />
         
        </div>
      </div>

      {showPopup && (
        <FilterPopup
          onClose={() => setShowPopup(false)}
          onSubmit={handleFilterSubmit}
        />
      )}
    </>
  );
}
