import React from 'react'
import QuestionsList from '../QA/QuestionsList'
import Navbar from '../components/Navbar'
import "../QA/QuestionsList.css"


export default function Answers() {
  return (
    <>
    <Navbar />
    <div>       
        <h2 style={{marginLeft:12}} className="qa-title">
            Questions for you 
        </h2>
        <QuestionsList mode="questions" />
    </div>
    </>
  )
}


