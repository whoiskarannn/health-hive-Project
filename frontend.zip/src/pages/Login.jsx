import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { loginUser } from "../api/authapi";
import "./css/Login.css";

export default function Login() {
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: "", password: "" });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      const res = await loginUser(form);

      // ✅ STORE USER (THIS MAKES NAVBAR WORK)
    localStorage.setItem("user", JSON.stringify(res.data.user));
        navigate("/");

    } catch (err) {
      setError(err.response?.data?.message || "Login failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-page">
      <div className="login-card">
        <h2>Login to HealthHive</h2>

        <form onSubmit={handleSubmit}>
          <input
            name="email" type="email" placeholder="Email address" onChange={handleChange} required disabled={loading} />
          <input
            name="password" type="password "placeholder="Password" onChange={handleChange} required disabled={loading} />
          <button type="submit" disabled={loading}>
            {loading ? "Logging in..." : "Login"}
          </button>
        </form>

        {error && <p className="error">{error}</p>}

        <p className="login-footer">
          Don’t have an account? <Link to="/register">Register Yourself</Link>
        </p>
      </div>
    </div>
  );
}
