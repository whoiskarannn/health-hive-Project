import { Routes, Route } from "react-router-dom";
import Home from "./pages/home.jsx";
import SpacePage from "./components/SpacePage.jsx";
import "leaflet/dist/leaflet.css";
import CreateSpace from './pages/CreatreSpace.jsx'
import MapPage from "./pages/MapPage.jsx";
import NotFound from "./components/NotFound.jsx";
import QuestionsList from "./QA/QuestionsList.jsx";
import AskPost from "./QA/AskPost.jsx";
import SearchResults from "./pages/searchResults.jsx";
import Answers from "./pages/Answers.jsx";
import Navbar from "./components/Navbar.jsx";   // not needed for now
import Register from "./pages/Register.jsx";
import VerifyEmail from "./pages/VerifyEmail.jsx";
import Profile from "./pages/Ptofile.jsx";
import Login from "./pages/Login.jsx";
// import dashbord from "./pages/DashBord.jsx"


function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />

      <Route path="/register" element={<Register />} />
      <Route path="/verify-email" element={<VerifyEmail />} />
      <Route path="/login" element={<Login />} />
      <Route path="/profile" element={<Profile />} />
      {/* <Route path="/dashbord" element={< />} /> */}

      <Route path="/create-space" element={<CreateSpace />} />
      <Route path="/mappage" element={<MapPage />} />

      {/* <Route path="/navbar" element={<Navbar />}/> */}
      <Route path="/QA" element={<QuestionsList />} />
      <Route path="/QA/ask" element={<AskPost />} />
      <Route path="/QA/answer" element={<Answers />} />

      <Route path="/search" element={<SearchResults />} />
      <Route path="/space/:slug" element={<SpacePage />} />

      <Route path="*" element={<NotFound />} />
    </Routes>


  );
}

export default App;
