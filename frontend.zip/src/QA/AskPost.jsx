import { useState, useEffect } from "react";
import "./AskPost.css";
import { createQuestion, createPost } from "../api/QAapi.js";
import AuthRequiredModal from  "../components/AuthRequiredModal.jsx"


function AskPost({ isOpen, activeTab = "ask", onClose }) {
  const user = JSON.parse(localStorage.getItem("user"));
  const [tab, setTab] = useState(activeTab);
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [showAuthPopup, setShowAuthPopup] = useState(false);



  useEffect(() => {
    setTab(activeTab);
  }, [activeTab]);

if (!isOpen) return null;

if (!user) {
  return (
    <AuthRequiredModal
      isOpen={true}
      onClose={onClose}
    />
  );
}

  
  const handleSubmit = async () => {
     try {
      if (tab === "ask") {
        await createQuestion({ title, content });
        console.log("Question added");
      }

      if (tab === "post") {
        await createPost({ title, content });
        console.log("Post created");
      }

      onClose();
    } catch (error) {
      console.error("Submission failed", error);
    }
  };

  return (
<>
    <div className="askpost-overlay">
      <div className="askpost-modal">
        {/* Header */}
        <div className="askpost-header">
          <div className="askpost-tabs">
            <button 
              className={tab === "ask" ? "active" : ""}
              onClick={() => setTab("ask")}
            >
              Ask
            </button>
            <button 
              className={tab === "post" ? "active" : ""}
              onClick={() => setTab("post")}
            >
              Post
            </button>
          </div>

          <button className="close-btn" onClick={onClose}>
            ✕
          </button>
        </div>

        {/* Body */}
        <div className="askpost-body">
          {tab === "ask" && (
            <>
              <input
                type="text"
                required
                placeholder="Start your question with What, Why, How, etc."
                value={title}
                onChange={(e) => setTitle(e.target.value)}
              />

              <textarea
              required
                placeholder="Add more details (optional)"
                value={content}
                onChange={(e) => setContent(e.target.value)}
              />

              <div className="meta-row">
                <span>📌 Medical</span>
                <span>🌐 Public</span>
              </div>
            </>
          )}

          {tab === "post" && (
            <>
              <input
                type="text"
                required
                placeholder="Write something"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
              />
              <textarea
              required
                placeholder="Say something..."
                value={content}
                onChange={(e) => setContent(e.target.value)}
              />

              <div className="meta-row">
                <span>🌐 Public</span>
              </div>
            </>
          )}
        </div>

        {/* Footer */}
        <div className="askpost-footer">
          <button className="cancel-btn" onClick={onClose}>
            Cancel
          </button>

          <button
            type="button"
            className="askpost-submit-btn"
            onClick={handleSubmit}
            
          >
            {tab === "ask" ? "Add Question" : "Post"}
          </button>


        </div>
      </div>
      
    </div>
    <AuthRequiredModal
      isOpen={showAuthPopup}
      onClose={() => setShowAuthPopup(false)}
    />
</>
    
  );
}


export default AskPost;

